local M={}

M.height = display.contentHeight
M.width = display.contentWidth
M.centerx = display.contentCenterX
M.centery = display.contentCenterY

M.largefont = display.contentWidth*0.067
M.bigfont = display.contentWidth*0.053
M.midfont = display.contentWidth*0.04
M.smallfont = display.contentWidth*0.032
M.TopBannerHeight=display.contentWidth*0.134
M.BoardHeight=display.contentWidth*0.05
M.BtnHeight=display.contentWidth*0.1
return M
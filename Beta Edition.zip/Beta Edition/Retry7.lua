-----------------------------------------------------------------------------------------
--
-- menu.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local sceneName=...

local composer=require("composer")
local widget=require("widget")


local sceneGroup

local scene=composer.newScene(sceneName)
local button1
local button2
local button3
-- local Sun={}
-- local Moon={}
local DarkMatter=nil
local Lay1
local Lay2
local Lay3
local width=display.contentWidth
local height=display.contentHeight


-- local function SunCreate()
-- 	for i=1,5 do 
-- 		Sun[i]=display.newCircle(sceneGroup,width/4,height/4,20)
-- 		Sun[i]:setFillColor(1,math.random(101,163)/255,0)
-- 		transition.to(Sun[i],{time=5000,xScale=5,yScale=5,alpha=0})
-- 	end
-- end
-- local function MoonCreate()
-- 	for i=1,5 do 
-- 		Moon[i]=display.newCircle(sceneGroup,width*(3/4),height*(3/4),20)
-- 		Moon[i]:setFillColor(math.random(101,230)/255,0,0)
-- 		transition.to(Moon[i],{time=5000,xScale=5,yScale=5,alpha=0})
-- 	end
-- end
local function DarkMatterCreate()
	DarkMatter=display.newRect(sceneGroup,math.random(0,width),math.random(0,height),10,10)
	DarkMatter:setFillColor(0,0,0)
	transition.to(DarkMatter,{time=1000,alpha=0,transition=inOutExpo,y=height})
end

function handleButtonEven1(event)
	if event.phase=="began" then
		print("started")
    elseif event.phase=="moved" then
    	print("moving")
    elseif event.phase=="ended" then
        composer.gotoScene("level7","slideUp",500)
    end
    return true

end
function handleButtonEven2(event)
	if event.phase=="began" then
		print("started")
    elseif event.phase=="moved" then
    	print("moving")
    elseif event.phase=="ended" then
        composer.gotoScene("menu","slideUp",500)
    end
    return true

end



function scene:create( event )
	sceneGroup=self.view
	Lay1=display.newRect(sceneGroup,width/2,height/6,width,height)
	  Lay1:setFillColor(77/255,0,77/255)
	Lay2=display.newRect(sceneGroup,width/2,height*(5/6),width,height)
	  Lay2:setFillColor(50/255,0,50/255)
	Lay3=display.newRect(sceneGroup,width/2,height*1.2,width,height)
	  Lay3:setFillColor(35/255,0,35/255)
	-- SunTimer=timer.performWithDelay(2000,SunCreate,-1)
 --    MoonTimer=timer.performWithDelay(2000,MoonCreate,-1)
	DarkMatterTimer=timer.performWithDelay(500,DarkMatterCreate,-1)



    button1=widget.newButton(
       {
	    label="button",
	    fontSize=width*0.08,
	    onEvent=handleButtonEven1,
	    emboss=false,
	    shape="circle",
	    radius=height*0.2,
		labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } },
	    fillColor={default={205/255,0,205/255,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=0

       }

	)

	button1.x=display.contentCenterX
	button1.y=height*0.5

	button1:setLabel("Retry")

	sceneGroup:insert(button1)
	button2=widget.newButton(
       {
	    label="button",
	    onEvent=handleButtonEven2,
	    emboss=false,
	    fontSize=width*0.04,
	    shape="circle",
	    radius=height*0.1,
	    labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } },
	    fillColor={default={205/255,0,205/255,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=0
       }

	)

	button2.x=width*0.1
	button2.y=height*0.9

	button2:setLabel("menu")

	sceneGroup:insert(button2)



	-- button3=widget.newButton(
 --       {
	--     label="button",
	--     onEvent=handleButtonEven3,
	--     emboss=false,

	--     shape="roundedRect",
	--     width=200,
	--     height=40,
	--     cornerRadius=2,
	--     fillColor={default={1,0,0,1},over={1,0.1,0.7,0.4}},
	--     strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	--     strokeWidth=4

 --       }

	-- )

	-- button3.x=display.contentCenterX
	-- button3.y=height*0.7

	-- button3:setLabel("level3")

	-- sceneGroup:insert(button3)






end

function scene:show(event)
	local sceneGroup=self.view
	local phase=event.phase

	if phase=="will"then


    elseif phase =="did"then

    end
end


function scene:hide(event)
	local sceneGroup=self.view
	local phase=event.phase

	if phase =="will"then


    elseif phase=="did"then

    end
end

function scene:destroy(event)
	local sceneGroup=self.view

end

scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)

return scene
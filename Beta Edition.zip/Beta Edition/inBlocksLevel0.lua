-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
--level1
local t={}
local blockModule=require("blockModule")
local width=display.contentWidth
local height=display.contentHeight
  t.create=function(sceneGroup)
  blockModule.create(sceneGroup,1,0,height*0.7,width*4,height*0.1,{type="plank",isFire=true,firePos={0.1,0.3,0.5,0.7,0.9}})

  blockModule.create(sceneGroup,5,0,height*0.7,width*2,height*0.1,{type="plank",win=true,winPos=0.5})
  -- blockModule.create(sceneGroup,1,width*0.6,height*0.5,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.075,0.925}})
  -- blockModule.create(sceneGroup,2,width*0.025,height*0.5,width*0.3,height*0.1,{type="plank",spike=true,spikePos={0.5}})
  -- blockModule.create(sceneGroup,2,width*0.45,height*0.6,width*0.3,height*0.1,{type="plank",spike=true,spikePos={}})
  -- blockModule.create(sceneGroup,2,width*0.85,height*0.75,width*0.5,height*0.1,{type="plank",spike=true,spikePos={0.5}})
  -- blockModule.create(sceneGroup,3,width*0.35,height*0.5,width*0.3,height*0.1,{type="plank",spike=true,spikePos={0.925}})
  -- blockModule.create(sceneGroup,3,width*0.75,height*0.7,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.5}})
  -- blockModule.create(sceneGroup,4,width*0.15,height*0.5,width*0.5,height*0.1,{type="plank",spike=true,spikePos={0.6}})
  -- blockModule.create(sceneGroup,4,width*0.7,height*0.3,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.075,0.925}})
  -- blockModule.create(sceneGroup,5,width*0.05,height*0.9,width,height*0.1,{type="plank",spike=true,spikePos={0.05,0.5,0.8}})
  -- blockModule.create(sceneGroup,5,width*0.1,height*0.3,width*1,height*0.1,{type="plank",spike=false,spikePos={0.3,0.6}})
  -- blockModule.create(sceneGroup,6,width*0.13,height*0.6,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.075,0.925}})
  -- blockModule.create(sceneGroup,6,width*0.5,height*0.6,width*0.5,height*0.1,{type="plank",spike=true,spikePos={0.5}})
  -- blockModule.create(sceneGroup,7,width*0.1,height*0.6,width*0.5,height*0.1,{type="plank",spike=true,spikePos={0.5}})
  -- blockModule.create(sceneGroup,7,width*0.65,height*0.6,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.6}})
  -- blockModule.create(sceneGroup,8,width*0.05,height*0.5,width*0.5,height*0.1,{type="plank",spike=true,spikePos={0.4}})
  -- blockModule.create(sceneGroup,8,width*0.65,height*0.7,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.95}})
  -- blockModule.create(sceneGroup,9,width*0.05,height*0.9,width*0.3,height*0.1,{type="plank",spike=false})
  -- blockModule.create(sceneGroup,9,width*0.45,height*0.75,width*0.1,height*0.1,{type="plank",spike=false})
  -- blockModule.create(sceneGroup,9,width*0.65,height*0.6,width*0.1,height*0.1,{type="plank",spike=false})
  -- blockModule.create(sceneGroup,9,width*0.85,height*0.8,width*0.3,height*0.1,{type="plank",spike=false})
  -- blockModule.create(sceneGroup,10,width*0.25,height*0.2,width*0.05,height*0.4,{type="plank",spike=false})
  -- blockModule.create(sceneGroup,10,width*0.25,height*0.95,width*0.05,height*0.4,{type="plank",spike=false})
  -- blockModule.create(sceneGroup,10,width*0.4,height*0.9,width,height*0.4,{type="plank",win=true,spike=false,winPos=0.4})

  t.blocks=blockModule.blocks
end
t.move=function()
	for i=1,#t.blocks do
		if t.blocks[i]~=nil then
      t.blocks[i]:translate(-width*0.007,0)
      --t.blocks[i]:translate(-width*0.007,0)
		end
	end
end
t.destroy=function()
  for i=1,#t.blocks do
    if t.blocks[i]~=nil then
      display.remove(t.blocks[i])
      t.blocks[i]=nil
    end
  end
end

return t 
   
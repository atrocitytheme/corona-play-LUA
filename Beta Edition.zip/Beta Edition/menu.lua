-----------------------------------------------------------------------------------------
--
-- menu.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local MyData = require( "MyData" )
local scene = composer.newScene()

-- include Corona's "widget" library
local widget = require "widget"

--------------------------------------------

-- forward declarations and other locals
local sceneGroup
local playBtn
-- local loadsave = require ("loadsave")
-- local Score = loadsave.loadTable("Score.json", system.DocumentsDirectory)
local particleDesigner = require( "particleDesigner" )


local scrollView
local function scrollListener( event )

	local phase = event.phase
	if ( phase == "began" ) then print( "Scroll view was touched" )
	elseif ( phase == "moved" ) then print( "Scroll view was moved" )
	elseif ( phase == "ended" ) then print( "Scroll view was released" )
	end

	-- In the event a scroll limit is reached...
	if ( event.limitReached ) then
		if ( event.direction == "up" ) then print( "Reached bottom limit" )
		elseif ( event.direction == "down" ) then print( "Reached top limit" )
		elseif ( event.direction == "left" ) then print( "Reached right limit" )
		elseif ( event.direction == "right" ) then print( "Reached left limit" )
		end
	end

	return true
end

local levelBG={}
local levelGroup={}
local levelBtns={}
-- local color1={182,251,255}
-- local color2={131,164,212}
-- local color2={243,161,131}
-- local color1={236,111,102}
local color2={10,10,10}
local color1={50,50,50}
local Layers=6
local StepsR=(color1[1]-color2[1])/Layers
local StepsG=(color1[2]-color2[2])/Layers
local StepsB=(color1[3]-color2[3])/Layers

local function handleButtonEvent(event )
	local phase=event.phase
	if phase=="began" then 

	elseif phase=="ended" then 
		composer.gotoScene( "level"..event.target.index,"slideUp")
	end
end

local function createLevelBG( ... )
	for i=1,9 do 
		levelBG[i] = display.newGroup()
		levelBG[i].x=0+(i-1)*MyData.width*0.3
		levelBG.y=scrollView.height*0.5


		bg=display.newRect(levelGroup[i],0,0,MyData.width*0.3,MyData.height)
		-- bg.x=0+(i-1)*MyData.width*0.3
		-- bg.y=scrollView.height*0.5
		bg.anchorX=0
		bg.anchorY=0

		bg:setFillColor((color1[1]-StepsR*(i-1))/255,(color1[2]-StepsG*(i-1))/255,(color1[3]-StepsB*(i-1))/255)
		levelBG[i]:insert(bg)
		-- scrollView:insert(bg)

		local body_radius = MyData.height*0.2

		local emitter = particleDesigner.newEmitter( "fire.json" )
		emitter.gravityy=-1000
		-- emitter.gravityx=-2000
		emitter.maxParticles=200
		emitter.angle=270
		emitter.duration=-1
		emitter.Speed=80
		emitter.particleLifespan=0.6
		emitter.startParticleSize=MyData.height*0.3

		emitter.x=bg.x+bg.width*0.5
		emitter.y=bg.height*0.5

		levelBG[i]:insert( emitter )


		Btn= widget.newButton(
			{
			width = MyData.height*0.2,
			height = MyData.height*0.2,
			defaultFile = "assets/Level_Btn/Red/Open/"..i..".png",
			overFile = "assets/Level_Btn/Red/Open_Over/"..i..".png",
			onEvent = handleButtonEvent
			}
		)
		Btn.x=bg.x+bg.width*0.5
		Btn.y=bg.height*0.5
		Btn.index=i
		levelBG[i]:insert(Btn)




		scrollView:insert(levelBG[i])

	end 
end

function scene:create( event )
	sceneGroup = self.view
	for i=1,9 do 
		levelGroup[i]=display.newGroup( )
	end 
	
	-- local highScore=display.newText("Score: "..Score[1].." highSchore: "..Score[2],0,0,textFont,MyData.bigfont)
	-- highScore.x=MyData.width*0.5
	-- highScore.y=MyData.height*0.2
	-- sceneGroup:insert(highScore)

	-- Create the widget
	scrollView = widget.newScrollView(
		{
		top = 0,
		left = 0,
		width = MyData.width,
		height = MyData.height,
		scrollWidth = MyData.width*3,
		scrollHeight = MyData.height,
		verticalScrollDisabled=true,
		isBounceEnabled=false,
		listener = scrollListener
		}
	)
	sceneGroup:insert( scrollView)
	createLevelBG()






end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
		-- local function StartLoad( ... )
		-- 	LoadMountain()
		-- end
		-- timer.performWithDelay(0,StartLoad)
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
		if scrollView then 
			display.remove( scrollView )
		end 
		for i=1,#levelBtns do 
			if levelBtns[i] then 
				display.remove(levelBtns[i])
			end 
		end 
		composer.removeScene("menu")
	end	
end

function scene:destroy( event )
	local sceneGroup = self.view
	package.loaded["MyData"] = nil

	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
	
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene


	local sceneName=...
	local composer=require("composer")
	local width=display.contentWidth
	local height=display.contentHeight
	local physics=require("physics")
		  physics.start()
	local scene=composer.newScene(sceneName)
	local widget=require("widget")
	local particleDesigner=require("particleDesigner")
	local button
	local backGround1
	local backGround2
	local backGround3
	-- local t = {}
	local moveTimer
	local button2
	local sceneGroup
	local stars={}
	


local function handleButton(event)
	if event.phase=="began" then
	elseif event.phase=="moved" then
	elseif event.phase=="ended" then
	
	composer.gotoScene("level7","slideUp",500)


	end
	return true
end

local function handleButton2(event)
	if event.phase=="began" then
	elseif event.phase=="moved" then
	elseif event.phase=="ended" then
	
	composer.gotoScene("menu","slideUp",500)


	end
	return true
end





function scene:create(event)
	local sceneGroup=self.view
	backGround1=display.newRect(sceneGroup,width/2,height/6,width,height/3)
	backGround1:setFillColor(0,0,1)
	backGround2=display.newRect(sceneGroup,width/2,height/2,width,height/3)
	backGround2:setFillColor(0,0,230/255)
	backGround3=display.newRect(sceneGroup,width/2,height*5/6,width,height/3)
	backGround3:setFillColor(0,0,204/255)





	-- movingObject1=display.newCircle(sceneGroup,width/2,height/2,width/30)
	-- movingObject1:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
	-- movingObject2=display.newCircle(sceneGroup,width/2,height/2,width/30)
	-- movingObject2:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
	-- movingObject3=display.newCircle(sceneGroup,width/2,height/2,width/30)
	-- movingObject3:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
	-- movingObject4=display.newCircle(sceneGroup,width/2,height/2,width/30)
	-- movingObject4:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
	

	-- transition.to(movingObject1,{alpha=0.5,xScale=3,x=width,y=height,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})
	-- transition.to(movingObject2,{alpha=0.5,xScale=3,x=width*0,y=height,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})
	-- transition.to(movingObject3,{alpha=0.5,xScale=3,x=width*0,y=height*0,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})
	-- transition.to(movingObject4,{alpha=0.5,xScale=3,x=width,y=height*0,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})


function blink()

for i=1,5 do
	stars[i]=display.newCircle(sceneGroup,math.random(0,width),0,width/30)
	stars[i]:setFillColor(1,math.random(100,150)/255,math.random(100,150)/255)
	transition.to(stars[i],{xScale=1,
                                
                                time=1500,
                                delay=0,
                                alpha=0,
                                
                                y=height,
                                transition=easing.linear,
                                
                                
                                })


end
end
	moveTimer=timer.performWithDelay(500,blink,-1)
	-- emitter=particleDesigner.newEmitter("fire.json")
 --        emitter.gravityy=0
 --        emitter.gravityx=-2000
 --        emitter.maxParticles=20
 --        emitter.angle=270
 --        emitter.duration=-1
 --        emitter.Speed=80
 --        emitter.particleLifespan=0.2
 --        emitter.x=width/2
 --        emitter.y=height/2
 --        emitter.startParticleSize=height*0.15
 --        emitter.finishParticleSize=height*0.02
 --        emitter.startColorRed=0.1
 --        emitter.startColorBlue=0.8
 --        emitter.startColorGreen=0.2

 --        local function updatePos()
 --          emitter.x=width/2
 --          emitter.y=width/2
 --        end 
 --      t.emitter=emitter
 --        updateEmitterTimer=timer.performWithDelay(1,updatePos,-1)

        


	button=widget.newButton(
       {
	    label="button",
	    onEvent=handleButton,
	    emboss=false,
	    fontSize=width*0.05,
	    shape="circle",
	    radius=width/10,
	    labelColor={default={1,1,1,1},over={0,0,0,1}},
	    fillColor={default={1,0.2,0.2,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=0

       }

	)

	button.x=width/2
	button.y=height/2

	button:setLabel("Continue")


	sceneGroup:insert(button)

	button=widget.newButton(
       {
	    label="button",
	    onEvent=handleButton2,
	    emboss=false,
	    fontSize=width*0.03,
	    shape="circle",
	    radius=width/18,
	    labelColor={default={1,1,1,1},over={1,1,1,1}},
	    fillColor={default={1,0.2,0.2,1},over={1,1,0,1}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=0

       }

	)

	button.x=width/10
	button.y=height*0.85

	button:setLabel("menu")


	sceneGroup:insert(button)


	

end




function scene:show(event)
		local sceneGroup=self.view
		local phase=event.phase
		if phase=="will" then 
		elseif phase=="did" then
		end
end



function scene:hide(event)
		local sceneGroup=self.view
		composer.removeScene("win")
end

   scene:addEventListener("create",scene)	 
   scene:addEventListener("show",scene)	 
   scene:addEventListener("hide",scene)	 
   scene:addEventListener("destroy",scene)	 
return scene
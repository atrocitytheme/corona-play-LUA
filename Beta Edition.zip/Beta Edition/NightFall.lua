t={}
local destroy
local create
local brighter
local darker
local i=0.001
local j=0
local gradient={
	type="gradient",
	color1={0,0,0,j},
	color2={0,0,0,i},
	direction="right"
}
local width=display.contentWidth
local height=display.contentHeight
local sceneGroup
local sky

t.create=function(sceneGroup)
	sky=display.newRect(sceneGroup,width/2,height/2,width,height)
	-- sky.ahchorX=0
	-- sky.anchorY=0
	sky.fill=gradient



	t.sky=sky
end

t.darker=function(sceneGroup)
	i=i+0.003
	j=j+0.001
	gradient.color1={0,0,0,j}
	gradient.color2={0,0,0,i}
	t.sky.fill=gradient
end

t.brighter=function(sceneGroup)
	i=0.2
	j=0
	gradient.color1={0,0,0,j}
	gradient.color2={0,0,0,i}
	t.sky.fill=gradient
end

t.destroy=function(sceneGroup)
	i=0.001
	j=0
	
	if t.sky~=nil then
		display.remove(t.sky)
	end
end
return t

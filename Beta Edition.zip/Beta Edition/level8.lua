local sceneName=...
local composer=require("composer")
local widget=require"widget"
local scene=composer.newScene(sceneName)
local height=display.contentHeight
local width=display.contentWidth
local iniBlocksLevel1=require("inBlocksLevel8")
local physics=require("physics")
local Blocks={}
local player
local foot
local emitter
local moveTimer
local gameOver
local backGround
local gameOver2
local nightFall=require("NightFall")
local gettingDark
local circle={}
local myTimer 
local Moon
local Shadow
local lighting
local effect
local effecta
local lighting1
local light1
physics.start()
-- physics.setDrawMode("hybrid")
physics.setGravity(0,width/8)
local playerModule=require("playerModule")

local function onLocalCollision(self,event)
	if(event.phase=="began") then
		if self.myName=="spike" then
			print("die!")
			timer.cancel(moveTimer)
			physics.pause()
			iniBlocksLevel1.destroy()
			display.remove(player)
			display.remove(foot)
			display.remove(gameOver)
			display.remove(backGround)
			display.remove(gameOver2)
			display.remove(emitter)
			display.remove(Moon)
			display.remove(Shadow)
			display.remove(lighting)
			display.remove(lighting1)
			timer.cancel(myTimer)
			timer.cancel(effect)
			timer.cancel(effecta)
			nightFall.destroy()
			Runtime:removeEventListener("enterFrame",gettingDark)
			for i=1,100 do 
				display.remove(circle[i])
			end

			composer.gotoScene("Retry8","slideUp",500)

		end
		if self.myName=="fire" then
			self.alpha=0
			nightFall.brighter()
		end
		-- print(self.myName..":collision began with"..event.other.myName)
		if self.myName=="foot" then 
			player.canJump=true
		end
		if self.myName=="win"then
			timer.cancel(moveTimer)
			physics.pause()
			iniBlocksLevel1.destroy()
			display.remove(player)
			display.remove(gameOver)
			display.remove(foot)
			display.remove(backGround)
			display.remove(gameOver2)
			display.remove(Moon)
			display.remove(emitter)
			display.remove(Shadow)
			display.remove(lighting)
			display.remove(lighting1)
			timer.cancel(effecta)
			timer.cancel(myTimer)
			nightFall.destroy()
			Runtime:removeEventListener("enterFrame",gettingDark)

			for i=1,100 do 
				display.remove(circle[i])
			end

			composer.gotoScene("Win8","slideUp",500)
		end
	elseif (event.phase=="ended") then
 		-- print(self.myName..":collision ended with"..event.other.myName)
 		if self.myName=="foot" then 
			player.canJump=false
			-- print("player cannot jump")
		end
	end
end

local highjumpTimer=nil
local function highjump( ... )
	physics.setGravity(0,width/5.5)
end

function jump(event)
	if event.phase=="began" then
		-- print("try to jump")
		physics.setGravity(0,0)
		if player.canJump==true then
			player:setLinearVelocity(0,-player.jumpForce)
		end
		highJumpTimer=timer.performWithDelay(300,highjump)

	elseif event.phase=="ended" then 
		physics.setGravity(0,width/5.5)
	end
end

local function moveBlocks()
	iniBlocksLevel1.move()


end


function gettingDark()
	nightFall.darker(sceneGroup)
end


function scene:create(event)
	local sceneGroup=self.view
	backGround=display.newRect(0,0,width,height)
	backGround.x=width/2
	backGround.y=height/2
	backGround:setFillColor(0,0,39/255)
	sceneGroup:insert(backGround)
	Moon=display.newCircle(sceneGroup,width*(3/4)+35,height*(1/4),width/20)
    Shadow=display.newCircle(sceneGroup,width*0.5+20,height/4,width/20)
    Shadow:setFillColor(0,0,39/255)
    transition.to(Shadow,{time=20000,x=width,iterations=-1,alpha=1})


	gameOver=display.newRect(sceneGroup,width/2,height*2,width*2,height*0.1)
	gameOver:setFillColor(0,1,0)
	gameOver.myName="spike"
	physics.addBody(gameOver,"static",{friction=0})
	gameOver.collision=onLocalCollision
	gameOver:addEventListener("collision")
	gameOver.isSensor=true
	


gameOver2=display.newRect(sceneGroup,-width*0.1,height/2,width*0.01,height*2)
	gameOver2:setFillColor(0,1,0)
	gameOver2.myName="spike"
	physics.addBody(gameOver2,"static",{friction=0})
	gameOver2.collision=onLocalCollision
	gameOver2:addEventListener("collision")
	gameOver2.isSensor=true


	playerModule.create(sceneGroup)
	player=playerModule.centerNode
	foot=playerModule.foot


	iniBlocksLevel1.create(sceneGroup)
	Blocks=iniBlocksLevel1.Blocks

 	for i=1,#Blocks do 
		Blocks[i].collision=onLocalCollision
		Blocks[i]:addEventListener("collision")
	end
	foot.collision=onLocalCollision
	foot:addEventListener("collision")
	sceneGroup:addEventListener("touch",jump)

	moveTimer=timer.performWithDelay(1,moveBlocks,-1)
	emitter=playerModule.emitter


local function bubble()
    for i=1,100 do
        local scale=math.random(10,20)/10
        circle[i].xScale=0.1
        circle[i].yScale=0.1
        circle[i].rotation=30
    transition.to(circle[i],{xScale=0.01,
                                yScale=math.random(10,11)/10,
                                time=1000,
                                delay=0,
                                alpha=1,
                                x=math.random(0,width),
                                y=math.random(0,height),
                                transition=easing.outElastic,
                                
                                })
    end
end

for i=1,100 do
    circle[i]= display.newCircle(sceneGroup,math.random(0,width),math.random(0,height),width/50)
    circle[i].xScale=0.1
    circle[i].yScale=1
    circle[i]:setFillColor(1,math.random(100,150)/255,math.random(100,150)/255)
end
    
myTimer=timer.performWithDelay(150,bubble,-1)

	
nightFall.create(sceneGroup)
Runtime:addEventListener("enterFrame",gettingDark)

function light()
	lighting=display.newCircle(sceneGroup,width,height/2,width/2)
	lighting:setFillColor(1,0,0)
	transition.to(lighting,{height=width/3,time=5000,rotation=60,delay=0})

end

effect=timer.performWithDelay(9000,light,-1)





function light1()
	lighting1=display.newCircle(sceneGroup,width*0,height/2,width/2)
	lighting1:setFillColor(1,0,0)
	transition.to(lighting1,{height=width/3,time=5000,rotation=60,delay=0})

end

effecta=timer.performWithDelay(9000,light1,-1)
end
 

function scene:show(event)
	local sceneGroup=self.view
	local phase=event.phase
	if phase=="will" then 
	elseif phase =="did" then
	end
end

function scene:hide(event)
    local sceneGroup=self.view
    composer.removeScene("level8")

end
function scene:destroy(event)
	local sceneGroup=self.view

end

   scene:addEventListener("create",scene)	 
   scene:addEventListener("show",scene)	 
   scene:addEventListener("hide",scene)	 
   scene:addEventListener("destroy",scene)	 
return scene

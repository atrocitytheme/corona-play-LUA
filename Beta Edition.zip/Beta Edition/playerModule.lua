-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local t={}
local width=display.contentWidth
local height=display.contentHeight
local particleDesigner=require("particleDesigner")

t.create=function(sceneGroup)


  centerNode=display.newCircle(sceneGroup,width*0.2,height*0.2,height*0.04)
  centerNode.canJump=false
  centerNode.myName="player"
  physics.addBody(centerNode,"dynamic",{density=0,friction=0,bounce=0})
  centerNode.gravityScale=1
  centerNode.isSleepingAllowed=false
  centerNode.jumpForce=height*1.3
  centerNode.isFixedRotation=true
  centerNode.isPlayer=true
  centerNode.alpha=0




  foot=display.newRect(sceneGroup,0,0,height*0.005,height*0.08)
  foot:setFillColor(0,0,0,0)
  foot:setStrokeColor(1,1,1,0)
  foot.strokeWidth=2
  foot.anchorY=0
  foot.x=width*0.2
  foot.y=centerNode.y
  physics.addBody(foot,"dynamic",{density=0,friction=0,bounce=0})
  foot.gravityScale=0
  foot.isSensor=true
  foot.myName="foot"
  foot.myBody=centerNode

  centerNode.foot=foot
  foot.myJoint=physics.newJoint("weld",foot,centerNode,foot.x,foot.y)

  t.centerNode=centerNode
  t.foot=foot

  emitter=particleDesigner.newEmitter("fire.json")
        emitter.gravityy=0
        emitter.gravityx=-2000
        emitter.maxParticles=20
        emitter.angle=270
        emitter.duration=-1
        emitter.Speed=80
        emitter.particleLifespan=0.2
        emitter.x=centerNode.x
        emitter.y=centerNode.y
        emitter.startParticleSize=height*0.15
        emitter.finishParticleSize=height*0.02
        emitter.startColorRed=0.1
        emitter.startColorBlue=0.8
        emitter.startColorGreen=0.2

        local function updatePos()
          emitter.x=centerNode.x
          emitter.y=centerNode.y
        end 
      t.emitter=emitter
        updateEmitterTimer=timer.performWithDelay(1,updatePos,-1)
        -- blocks[#blocks]:insert(emitter)

        -- physics.addBody(blocks[#blocks],"static",{density=0,friction=0,bounce=1,radius=body_radius})
        -- blocks[#blocks].isSensor=true
        -- blocks[#blocks].myName="fire"
        -- sceneGroup:insert(blocks[#blocks])



end










return t
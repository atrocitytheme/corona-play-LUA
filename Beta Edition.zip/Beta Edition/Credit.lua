

	local sceneName=...
	local composer=require("composer")
	local width=display.contentWidth
	local height=display.contentHeight
	local scene=composer.newScene(sceneName)
	local widget=require("widget")
	local button1
	local button2
	local button3
	local button4
	local sceneGroup
	


local function handleButton1(event)
	if event.phase=="began" then
	elseif event.phase=="moved" then
	elseif event.phase=="ended" then
	composer.gotoScene("menu","slideUp",500)
	end
	return true
end

local function handleButton2(event)
	if event.phase=="began" then
	elseif event.phase=="moved" then
	elseif event.phase=="ended" then
	composer.gotoScene("menu","slideUp",500)
	end
	return true
end

local function handleButton3(event)
	if event.phase=="began" then
	elseif event.phase=="moved" then
	elseif event.phase=="ended" then
	composer.gotoScene("menu","slideUp",500)
	end
	return true
end
local function handleButton4(event)
	if event.phase=="began" then
	elseif event.phase=="moved" then
	elseif event.phase=="ended" then
	composer.gotoScene("menu","slideUp",500)
	end
	return true
end






function scene:create(event)
	 sceneGroup=self.view
-- 	backGround1=display.newRect(sceneGroup,width/2,height/6,width,height/3)
-- 	backGround1:setFillColor(0.3,0.7,0.8)
-- 	backGround2=display.newRect(sceneGroup,width/2,height/2,width,height/3)
-- 	backGround2:setFillColor(0.4,0.6,0.5)
-- 	backGround3=display.newRect(sceneGroup,width/2,height*5/6,width,height/3)
-- 	backGround3:setFillColor(0.5,0.7,0.7)





-- 	movingObject1=display.newCircle(sceneGroup,width/2,height/2,width/30)
-- 	movingObject1:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
-- 	movingObject2=display.newCircle(sceneGroup,width/2,height/2,width/30)
-- 	movingObject2:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
-- 	movingObject3=display.newCircle(sceneGroup,width/2,height/2,width/30)
-- 	movingObject3:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
-- 	movingObject4=display.newCircle(sceneGroup,width/2,height/2,width/30)
-- 	movingObject4:setFillColor(math.random(0,0.1),math.random(0,0.3),math.random(0,255)/255)
	

-- 	transition.to(movingObject1,{alpha=0.5,xScale=3,x=width,y=height,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})
-- 	transition.to(movingObject2,{alpha=0.5,xScale=3,x=width*0,y=height,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})
-- 	transition.to(movingObject3,{alpha=0.5,xScale=3,x=width*0,y=height*0,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})
-- 	transition.to(movingObject4,{alpha=0.5,xScale=3,x=width,y=height*0,transition=easing.outElastic,time=10000,delay=0,iterations=-1,rotation=720})


-- function blink()

-- for i=1,10 do
-- 	stars[i]=display.newCircle(sceneGroup,width/math.random(1,10),height*math.random(0,1),width/30)
-- 	stars[i]:setFillColor(1,math.random(100,150)/255,math.random(100,150)/255)
-- 	transition.to(stars[i],{xScale=0.01,
--                                 yScale=math.random(10,11)/10,
--                                 time=1500,
--                                 delay=0,
--                                 alpha=0,
--                                 x=math.random(0,width),
--                                 y=math.random(0,height),
--                                 transition=easing.outElastic,
                                
--                                 })


-- end
-- end
-- 	moveTimer=timer.performWithDelay(500,blink,-1)

	button1=widget.newButton(
       {
	    label="button",
	    onEvent=handleButton1,
	    emboss=false,
	    fontSize=height/10,
	    shape="roundedRect",
	    width=width/2,
	    height=height/10,
	    cornerRadius=2,
	    fillColor={default={1,0,0,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=4

       }

	)

	button1.x=display.contentCenterX
	button1.y=height*0.2

	button1:setLabel("Thanks for Tony")

	sceneGroup:insert(button1)


	button2=widget.newButton(
       {
	    label="button",
	    onEvent=handleButton2,
	    emboss=false,
	    fontSize=height*0.1,
	    shape="roundedRect",
	    width=width/2,
	    height=height/10,
	    cornerRadius=2,
	    fillColor={default={1,0,0,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=4

       }

	)

	button2.x=display.contentCenterX
	button2.y=height*0.4

	button2:setLabel("Menu design Tony")

	sceneGroup:insert(button2)

	button3=widget.newButton(
       {
	    label="button",
	    onEvent=handleButton3,
	    emboss=false,
	    fontSize=height/10,
	    shape="roundedRect",
	    width=width/2,
	    height=height/10,
	    cornerRadius=2,
	    fillColor={default={1,0,0,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=4

       }

	)

	button3.x=display.contentCenterX
	button3.y=height*0.6

	button3:setLabel("level design Tomson")

	sceneGroup:insert(button3)

	button4=widget.newButton(
       {
	    label="button",
	    onEvent=handleButton4,
	    emboss=false,
	    fontSize=height/10,
	    shape="roundedRect",
	    width=width/2,
	    height=height/10,
	    cornerRadius=2,
	    fillColor={default={1,0,0,1},over={1,0.1,0.7,0.4}},
	    strokeColor={default={1,0.4,0,1},over={0.8,0.8,1,1}},
	    strokeWidth=4

       }

	)

	button4.x=display.contentCenterX
	button4.y=height*0.8

	button4:setLabel("level design Joel ")

	sceneGroup:insert(button4)



	

end




function scene:show(event)
		local sceneGroup=self.view
		local phase=event.phase
		if phase=="will" then 
		elseif phase=="did" then
		end
end



function scene:hide(event)
		local sceneGroup=self.view
		composer.removeScene("win")
end

   scene:addEventListener("create",scene)	 
   scene:addEventListener("show",scene)	 
   scene:addEventListener("hide",scene)	 
   scene:addEventListener("destroy",scene)	 
return scene
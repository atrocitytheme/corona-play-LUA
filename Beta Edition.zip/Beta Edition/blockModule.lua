-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local t={}
local blocks={}
local spikeWidth=display.contentHeight*0.07
local spikeHeight=display.contentHeight*0.07
local Screenwidth=display.contentWidth
local particleDesigner=require("particleDesigner")
-- local height=display.contentHeight

t.create=function(sceneGroup,screen,x,y,width,height,blockType)
	if blockType.type=="box"then

	elseif blockType.type=="plank"then
		blocks[#blocks+1]=display.newRect(sceneGroup,x,y,width,height)
		blocks[#blocks]:setFillColor(math.random(0,255)/255,math.random(0,255)/255,math.random(0,255)/255)
		blocks[#blocks].anchorX=0
		blocks[#blocks].x=x+(screen-1)*Screenwidth
		blocks[#blocks].y=y
		blocks[#blocks].myName="plank"
		blocks[#blocks]:setFillColor(226/255,226/255,226/255)

		physics.addBody(blocks[#blocks],"static",{friction=0})
		if blockType.spike==true then
			local imageFile="assets/spike/spike.png"
			local imageOutline=graphics.newOutline(5,imageFile)

			for i=1,#blockType.spikePos do
				blocks[#blocks+1]=display.newImageRect(sceneGroup,"assets/spike/spike.png",spikeWidth,spikeHeight)
				blocks[#blocks].anchorX=0.5
				blocks[#blocks].anchorY=0.5
				blocks[#blocks].x=blocks[#blocks-i].x+blocks[#blocks-i].width*blockType.spikePos[i]
				blocks[#blocks].y=blocks[#blocks-i].y-blocks[#blocks-i].height*0.5-spikeHeight*0.5
				blocks[#blocks].myName="spike"
				physics.addBody(blocks[#blocks],"static",{outline=imageOutline})

				blocks[#blocks].isSensor=true
			end

		end

		if blockType.win==true then
			blocks[#blocks+1]=display.newRect(sceneGroup,0,0,spikeWidth,spikeHeight*100)
			blocks[#blocks].anchorX=0.5
			blocks[#blocks].anchorY=0.5
			blocks[#blocks].x=blocks[#blocks-1].x+blocks[#blocks-1].width*blockType.winPos
			blocks[#blocks].y=blocks[#blocks-1].y+blocks[#blocks-1].height*0.5-spikeHeight*50
			blocks[#blocks].myName="win"
			physics.addBody(blocks[#blocks],"static",{friction=0})
			blocks[#blocks].isSensor=true
			blocks[#blocks].alpha=1
			blocks[#blocks]:setFillColor(226/255,226/255,226/255)
		end

		if blockType.isFire==true then
			for i=1,#blockType.firePos do
				local body_radius=spikeWidth/2

				blocks[#blocks+1]=display.newGroup()
				blocks[#blocks].x=blocks[#blocks-i].x+blocks[#blocks-i].width*blockType.firePos[i]
				blocks[#blocks].y=blocks[#blocks-i].y-blocks[#blocks-i].height*0.5-spikeHeight*3.5


				local c=display.newCircle(0,0,body_radius)
				c:setFillColor(0,0,0,0)
				blocks[#blocks]:insert(c)

				local emitter=particleDesigner.newEmitter("fire.json")
				emitter.gravityy=-1000
				emitter.maxParticles=50
				emitter.angle=270
				emitter.duration=-1
				emitter.Speed=80
				emitter.particleLifespan=0.1
				blocks[#blocks]:insert(emitter)

				physics.addBody(blocks[#blocks],"static",{density=0,friction=0,bounce=1,radius=body_radius})
				blocks[#blocks].isSensor=true
				blocks[#blocks].myName="fire"
				sceneGroup:insert(blocks[#blocks])
			end
		end
	elseif blockType.type=="special"then

	end

	for i=1,#blocks do
		blocks[i].index=i
	end
	t.blocks=blocks	


end

return t
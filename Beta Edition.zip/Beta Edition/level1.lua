-----------------------------------------------------------------------------------------
--
-- menu.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
--level1
local sceneName=...
local width=display.contentWidth
local height=display.contentHeight

local Stars={}
local Moon
local Shadow
local Sky
local SignalLine={}


local composer=require("composer")
local widget=require("widget")
local iniBlocksLevel1=require("inBlocksLevel1")
local physics = require("physics")
local createPlayer=require("playerModule")
local nightFall=require("NightFall")


physics.start()
--physics.setDrawMode("hybrid")
physics.setGravity(0,width/5.5)
local sceneGroup
local scene=composer.newScene(sceneName)
local player 
local foot
local emitter

local blocks={}
local moveTimer
local cliff
local Sky


local function gettingDark()
	nightFall.darker(sceneGroup)
end
local function onLocalCollision(self,event)
	if(event.phase=="began")then
		if self.myName=="foot"then
			player.canJump=true

			print("player can jump now")
		end
		if self.myName=="win"then
			timer.cancel(moveTimer)
			physics.pause()
			iniBlocksLevel1.destroy()
			display.remove(player)
			display.remove(foot)
			display.remove(emitter)
			nightFall.destroy()
			Runtime:removeEventListener("enterFrame",gettingDark)
			timer.cancel(StarTimer1)
			timer.cancel(StarTimer2)
			composer.gotoScene("Win1","slideUp",500)

			--timer.cancel(SignalLineTimer)
		end
		print(self.myName..":collision began with "..event.other.myName)
 		if self.myName=="spike" then
 			print("you die")
 			timer.cancel(moveTimer)
			physics.pause()
			iniBlocksLevel1.destroy()
			display.remove(player)
			display.remove(foot)
			display.remove(emitter)
			nightFall.destroy()
			Runtime:removeEventListener("enterFrame",gettingDark)
			timer.cancel(StarTimer1)
			timer.cancel(StarTimer2)
				composer.gotoScene("Retry1","slideUp",500)


			--timer.cancel(SignalLineTimer)
		end
		if self.myName=="fire" then
			self.alpha=0
			nightFall.brighter(sceneGroup)
		end
 	elseif(event.phase=="ended")then
	 	if self.myName=="foot"then
				player.canJump=false
				print("player cannot jump now")
			end
 	    print(self.myName..":collision ended with "..event.other.myName)
 	end
end
local highJumpTimer=nil
local function highJump(...)
	physics.setGravity(0,width/5.5)
end
local function jump(event)
	if event.phase=="began" then
		physics.setGravity(0,0)
		if player.canJump==true then
			player:setLinearVelocity(0,-player.jumpForce)
		end
			highJumpTimer=timer.performWithDelay(300,highJump)
	elseif event.phase=="ended"then
		physics.setGravity(0,width/5.5)

    end
end
local function moveBlocks()
	iniBlocksLevel1.move()
end

local function Starscreate1()
	for i=1,10 do 
	Stars[i]=display.newRect(sceneGroup,math.random(0,width*(1/2)),math.random(0,height),10,10)
		transition.to(Stars[i],{alpha=0,timer=50000,x=Stars[i].x,y=Stars[i].y,iterations=-1})
		Stars[i]:setFillColor(1,1,77/255)
    end
end
local function Starscreate2()
	 for i=1,10 do 
	 	Stars[i]=display.newRect(sceneGroup,math.random(width/2,width),math.random(height/2,height),10,10)
		transition.to(Stars[i],{alpha=0,timer=50000,x=Stars[i].x,y=Stars[i].y,iterations=-1})
		Stars[i]:setFillColor(1,1,77/255)
	end
end

-- local function SignalLineCreate1()
-- 	for i=1,2 do
-- 		SignalLine[i]=display.newCircle(sceneGroup,math.random(0,width),math.random(0,height),5)
-- 		transition.to(SignalLine[i],{xScale=200,time=100,alpha=0})
-- 		SignalLine[i]:setFillColor(0,0,0)
-- 	end
-- end


function scene:create( event )
	sceneGroup=self.view
	Sky=display.newRect(sceneGroup,width/2,height/2,width,height)
	  Sky:setFillColor(0,0,96/255)

	Moon=display.newCircle(sceneGroup,width*(3/4),height*(1/4),50)
   	Shadow=display.newCircle(sceneGroup,width*(1/3),height/4,50)
   	Shadow:setFillColor(0,0,96/255)
    transition.to(Shadow,{time=50000,x=width*1.1,iterations=-1})

    StarTimer1=timer.performWithDelay(10,Starscreate1)
    StarTimer2=timer.performWithDelay(10,Starscreate2)
    --SignalLineTimer=timer.performWithDelay(1,SignalLineCreate1,-1)

		cliff=display.newRect(sceneGroup,0,0,width,height*0.1)
		cliff:setFillColor(math.random(0,255)/255,math.random(0,255)/255,math.random(0,255)/255,1)
		cliff.anchorX=0
		cliff.x=0
		cliff.y=height*1.1
		cliff.myName="spike"
	

		physics.addBody(cliff,"static",{friction=0})
		cliff.isSensor=true

		cliff.collision=onLocalCollision
		cliff:addEventListener("collision")

	iniBlocksLevel1.create(sceneGroup)
    blocks=iniBlocksLevel1.blocks
	


	createPlayer.create(sceneGroup)
	player=createPlayer.centerNode
	foot=createPlayer.foot
	foot:setFillColor(0,0,0,0)
	emitter=createPlayer.emitter
	


	for i=1,#blocks do 
		blocks[i].collision=onLocalCollision
		blocks[i]:addEventListener("collision")
	end

	foot.collision=onLocalCollision
	foot:addEventListener("collision")
	sceneGroup:addEventListener("touch",jump)
	moveTimer=timer.performWithDelay(1,moveBlocks,-1)
	nightFall.create(sceneGroup)
	Runtime:addEventListener("enterFrame",gettingDark)
	
end

function scene:show(event)
	local sceneGroup=self.view
	local phase=event.phase

	if phase=="will"then


    elseif phase =="did"then

    end
end


function scene:hide(event)
	local sceneGroup=self.view
	local phase=event.phase

	if phase =="will"then


    elseif phase=="did"then
    	composer.removeScene("level1")

    end
end

function scene:destroy(event)
	local sceneGroup=self.view

end

scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)

return scene
-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
--level2
local width=display.contentWidth
local height=display.contentHeight
local t={}
local blockModule=require("blockModule")
t.move=function()
	for i=1,#t.Blocks do
		if t.Blocks[i]~=nil then
			t.Blocks[i]:translate(-width*0.007,0)
			--height(max)=0.3  width(max)=0.2 +0.001 each
		end
	end


end


t.create=function(sceneGroup)
	blockModule.create(sceneGroup,1,width*0,height*0.4,width*0.5,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,1,width*0.6,height*0.5,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,1,width*0.77,height*0.6,width*0.35,height*0.1,{type="plank",isFire=true,firePos={0.3}})
	
	blockModule.create(sceneGroup,2,width,height*0.5,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,2,width*0.15,height*0.5,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,2,width*0.35,height*0.5,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,2,width*0.55,height*0.5,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,2,width*0.8,height*0.5,width*0.1,height*0.1,{type="plank",isFire=true,firePos={0.5}})
	blockModule.create(sceneGroup,3,width*0.2,height*0.4,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,3,width*0.4,height*0.2,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})

	blockModule.create(sceneGroup,3,width*0.64,height*0.6,width*0.1,height*0.16,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,3,width*0.8,height*0.5,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,3,width,height*0.5,width*0.25,height*0.1,{type="plank",isFire=true,firePos={0.3}})
	blockModule.create(sceneGroup,4,width*0.3,height*0.5,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,4,width*0.55,height*0.5,width*0.15,height*0.1,{type="plank",isFire=true,firePos={0.3}})
	blockModule.create(sceneGroup,4,width*0.7,height*0.25,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,4,width*0.9,height*0.4,width*0.1,height*0.1,{type="plank",isFire=true,firePos={0.7}})
	blockModule.create(sceneGroup,5,width*0.15,height*0.25,width*0.1,height*0.1,{type="plank",isFire=true,firePos={0.6}})	
	blockModule.create(sceneGroup,5,width*0.3,height*0.4,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,5,width*0.5,height*0.25,width*0.2,height*0.1,{type="plank",isFire=true,firePos={0.4}})
	blockModule.create(sceneGroup,5,width*0.8,height*0.3,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})

	blockModule.create(sceneGroup,6,width*0,height*0.2,width*0.5,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,6,width*0.9,height*0.5,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,6,width*0.5,height*0.5,width*0.3,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	-- blockModule.create(sceneGroup,1,width,height*0.5,width*0.1,height*0.1,{type="plank",isFire=true,firePos={0.45}})
	blockModule.create(sceneGroup,7,width*0.15,height*0.5,width*0.15,height*0.1,{type="plank",isFire=true,firePos={0.6}})

	blockModule.create(sceneGroup,7,width*0.35,height*0.5,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,7,width*0.55,height*0.5,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,7,width*0.8,height*0.5,width*0.2,height*0.1,{type="plank",isFire=true,firePos={0.7}})
	blockModule.create(sceneGroup,8,width*0.05,height*0.4,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,8,width*0.2,height*0.4,width*0.2,height*0.1,{type="plank",isFire=true,firePos={0.5}})
	-- blockModule.create(sceneGroup,3,width*0.3,height*0.3,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,8,width*0.4,height*0.2,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})

	blockModule.create(sceneGroup,8,width*0.64,height*0.6,width*0.1,height*0.16,{type="plank",isFire=true,firePos={0.9}})
	blockModule.create(sceneGroup,8,width*0.8,height*0.45,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,8,width,height*0.5,width*0.25,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,9,width*0.3,height*0.55,width*0.2,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,9,width*0.55,height*0.5,width*0.15,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,9,width*0.7,height*0.3,width*0.1,height*0.1,{type="plank",isFire=true,firePos={0.7}})
	blockModule.create(sceneGroup,9,width*0.9,height*0.4,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,10,width*0.15,height*0.25,width*0.1,height*0.1,{type="plank",isFire=true,firePos={0.8}})	
	blockModule.create(sceneGroup,10,width*0.3,height*0.4,width*0.1,height*0.1,{type="plank",spike=false,spikePos={0.1,0.9}})
	blockModule.create(sceneGroup,10,width*0.5,height*0.25,width*0.2,height*0.1,{type="plank",isFire=true,firePos={0.8}})
	
blockModule.create(sceneGroup,10,width*0.7,height*0.75,width*0.4,height*0.1,{type="plank",win=true,winPos=0.4})
	
t.Blocks=blockModule.blocks
end
t.destroy=function()
  for i=1,#t.Blocks do
    if t.Blocks[i]~=nil then
      display.remove(t.Blocks[i])
      t.Blocks[i]=nil
    end
  end
end
return t
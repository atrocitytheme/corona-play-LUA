-----------------------------------------------------------------------------------------
--
-- menu.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
--level1
local sceneName=...
local width=display.contentWidth
local height=display.contentHeight

local Lay1
local Lay2
local Lay3
local Lava={}
-- local function Lavacreate()
-- 	for i=1,6 do 
-- 		Lava[i]=display.newRect(sceneGroup,math.random(0,width),0,width/10,height/2)
-- 		Lava[i]:setFillColor(1,101/255,0)
-- 		transition.to(Lava[i],{time=5000,y=height*2,xScale=1/2})
-- 	end
-- end
	-- Lay1=display.newRect(width/2,height/6,width,height/3)
 --    Lay1:setFillColor(1,123/255,0)
 --    Lay2=display.newRect(width/2,height/2,width,height/3)
 --    Lay2:setFillColor(1,165/255,0)
 --    Lay3=display.newRect(width/2,height*(5/6),width,height/3)
 --    Lay3:setFillColor(1,208/255,0)
 --    LavaTimer=timer.performWithDelay(2000,Lavacreate,-1)




local composer=require("composer")
local widget=require("widget")
local iniBlocksLevel1=require("inBlocksLevel0")
local physics = require("physics")
local createPlayer=require("playerModule")
local nightFall=require("NightFall")


physics.start()
--physics.setDrawMode("hybrid")
physics.setGravity(0,width/5.5)
local sceneGroup
local scene=composer.newScene(sceneName)
-- local width=display.contentWidth
-- local height=display.contentHeight
local player 
local foot
local blocks={}
local moveTimer
local cliff

local function gettingDark()
	nightFall.darker(sceneGroup)
end
local function onLocalCollision(self,event)
	if(event.phase=="began")then
		if self.myName=="foot"then
			player.canJump=true

			print("player can jump now")
		end
		if self.myName=="win"then
			timer.cancel(moveTimer)
			physics.pause()
			iniBlocksLevel1.destroy()
			display.remove(player)
			display.remove(foot)
			nightFall.destroy()
			Runtime:removeEventListener("enterFrame",gettingDark)
			composer.gotoScene("Win","slideUp",500)
		end
		print(self.myName..":collision began with "..event.other.myName)
 		if self.myName=="spike" then
 			print("you die")
 			timer.cancel(moveTimer)
			physics.pause()
			iniBlocksLevel1.destroy()
			display.remove(player)
			display.remove(foot)
			nightFall.destroy()
			Runtime:removeEventListener("enterFrame",gettingDark)
			composer.gotoScene("menu","slideUp",500)
		end
        if self.myName=="fire" then
        	self.alpha=0
        	nightFall.brighter()
        end
 	elseif(event.phase=="ended")then
	 	if self.myName=="foot"then
				player.canJump=false
				print("player cannot jump now")
			end
 	    print(self.myName..":collision ended with "..event.other.myName)
 	end
end
local highJumpTimer=nil
local function highJump(...)
	physics.setGravity(0,width/5.5)
end
local function jump(event)
	if event.phase=="began" then
		physics.setGravity(0,0)
		if player.canJump==true then
			player:setLinearVelocity(0,-player.jumpForce)
		end
			highJumpTimer=timer.performWithDelay(300,highJump)
	elseif event.phase=="ended"then
		physics.setGravity(0,width/5.5)

    end
end
local function moveBlocks()
	iniBlocksLevel1.move()
end


local function Lavacreate()
	for i=1,6 do 
		Lava[i].x=math.random(0,width)
	end
	for i=1,6 do

		transition.to(Lava[i],{iterations=-1,time=5000,y=height*2,x=math.random(0,width),xScale=1/2})
	end
end

function scene:create( event )
	sceneGroup=self.view
	--nightFall.create(sceneGroup)



	Lay1=display.newRect(sceneGroup,width/2,height/6,width,height/3)
    Lay1:setFillColor(1,123/255,0)
    Lay2=display.newRect(sceneGroup,width/2,height/2,width,height/3)
    Lay2:setFillColor(1,165/255,0)
    Lay3=display.newRect(sceneGroup,width/2,height*(5/6),width,height/3)
    Lay3:setFillColor(1,208/255,0)


	for i=1,6 do 
		Lava[i]=display.newRect(sceneGroup,math.random(width/3,width/2),-height*0.5,width/10,height/2)
		Lava[i]:setFillColor(1,101/255,0)
	end
	    LavaTimer=timer.performWithDelay(10,Lavacreate,1)

		cliff=display.newRect(sceneGroup,0,0,width,height*0.1)
		cliff:setFillColor(math.random(0,255)/255,math.random(0,255)/255,math.random(0,255)/255,1)
		cliff.anchorX=0
		cliff.x=0
		cliff.y=height*1.1
		cliff.myName="spike"
	

		physics.addBody(cliff,"static",{friction=0})
		cliff.isSensor=true

		cliff.collision=onLocalCollision
		cliff:addEventListener("collision")

	iniBlocksLevel1.create(sceneGroup)
    blocks=iniBlocksLevel1.blocks
	createPlayer.create(sceneGroup)
	player=createPlayer.centerNode
	foot=createPlayer.foot
	foot:setFillColor(0,0,0,0)
	for i=1,#blocks do 
		blocks[i].collision=onLocalCollision
		blocks[i]:addEventListener("collision")
	end

	foot.collision=onLocalCollision
	foot:addEventListener("collision")
	sceneGroup:addEventListener("touch",jump)
	moveTimer=timer.performWithDelay(1,moveBlocks,-1)
	nightFall.create(sceneGroup)
	Runtime:addEventListener("enterFrame",gettingDark)
   
end

function scene:show(event)
	local sceneGroup=self.view
	local phase=event.phase

	if phase=="will"then


    elseif phase =="did"then

    end
end


function scene:hide(event)
	local sceneGroup=self.view
	local phase=event.phase

	if phase =="will"then


    elseif phase=="did"then
    	composer.removeScene("level1")

    end
end

function scene:destroy(event)
	local sceneGroup=self.view

end

scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)

return scene
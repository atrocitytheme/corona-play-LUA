local M = {}
M.fitImage = function (displayObject, fitWidth, fitHeight, enlarge)
	local scaleFactor = fitHeight/ displayObject.height
	local newWidth = displayObject.width * scaleFactor
	if newWidth >=fitWidth then
		scaleFactor = fitWidth/displayObject.width
	end
	if not enlarge and scaleFactor > 1 then
		return
	end
	displayObject:scale( scaleFactor, scaleFactor)
end
-- doesFileExist
M.doesFileExist = function (fname, path)
	local results = false
	local filePath = system.pathForFile(fname, path)
	if filePath then 
		filePath = io.open(filePath, "r")
	end
	if filePath then 
		filePath:close()
		results = true
	else
		print("File does not exist -> "..fname)
	end
	return results
end
return M
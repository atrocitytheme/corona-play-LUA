local M = {}
local circle={}
local MyData=require("MyData")
local widget=require("widget")

local function hide( ... )
	transition.to(circle[2],{alpha=0,time=500})
end
function M.show( ... )
	-- body
	transition.to(circle[2],{alpha=1,time=500,onComplete=hide})
end


local function buttonTouch( event )
	-- body
	print(event.phase)
	if event.phase=="ended" then 
		M.show()
		M.callback(true)
	end  

end
function M.init(sceneGroup,x,y,listener)

	if ( listener and type(listener) == "function" ) then
        M.callback = listener
    else
        error( "No callback function listed" )
    end

	circle[1]=display.newCircle(sceneGroup,x,y,MyData.width*0.025)
	circle[1].strokeWidth=MyData.height*0.005
	circle[1]:setFillColor(1,1,1,0)

	circle[2]=display.newCircle(sceneGroup,x,y,MyData.width*0.01)
	circle[2]:setFillColor(1,1,1)
	circle[2].alpha=0

	local button=widget.newButton( {
		shape="roundedRect",
		width=MyData.TopBannerHeight,
		height=MyData.TopBannerHeight,
		fillColor={default={1,0,0},over={0,0,1}},
		onEvent=buttonTouch
	} )
	button.alpha=0
	button.isHitTestable=true	
	button.anchorX=1
	button.x=MyData.width
	button.y=y	
	sceneGroup:insert(button)

end


local function buttonTouchWeb(event)
	M.callback(event)
end
function M.initWebView(sceneGroup,x,y,listener)

	if ( listener and type(listener) == "function" ) then
        M.callback = listener
    else
        error( "No callback function listed" )
    end

	circle[1]=display.newCircle(sceneGroup,x,y,MyData.width*0.025)
	circle[1].strokeWidth=MyData.height*0.005
	circle[1]:setFillColor(1,1,1,0)

	circle[2]=display.newCircle(sceneGroup,x,y,MyData.width*0.01)
	circle[2]:setFillColor(1,1,1)
	circle[2].alpha=0

	local button=widget.newButton( {
		shape="roundedRect",
		width=MyData.TopBannerHeight,
		height=MyData.TopBannerHeight,
		fillColor={default={1,0,0},over={0,0,1}},
		onEvent=buttonTouchWeb
	} )
	button.alpha=0
	button.isHitTestable=true	
	button.anchorX=1
	button.x=MyData.width
	button.y=y	
	sceneGroup:insert(button)

end

return M
local M = {}
local widget=require("widget")
local MyData=require("MyData")
local commentTempObj={}

	local comment_Text=""
    local function handleTextField( getObj )
        return function( event )
            -- print( "TextField Object is: " .. tostring( getObj() ) )
            if event.phase=="began" then 

            elseif event.phase == "ended" then
             
                comment_Text=event.target.text

            elseif event.phase == "editing" then
                local txt = event.target.text
                
                comment_Text=txt
            end
        end     
    end


---------------------------------handle text input--------------------------
    local StringLenInputChn=0
    local function handleTextField( getObj )
    -- Use Lua closure in order to access the TextField object
        return function( event )
            -- print( "TextField Object is: " .. tostring( getObj() ) )
            if event.phase=="began" then 

            elseif event.phase == "ended" then
                -- do something with textBox text
                print( event.target.text )
                comment_Text=event.target.text
                print("text event ended@@@@@")

            elseif event.phase == "editing" then
                local txt = event.target.text
                -- check for english and chinese count
                for word in event.target.text:gmatch("[^\128-\191][\128-\191]*") do
                    print("chinese word:"..word)
                    StringLenInputChn=StringLenInputChn+1
                    -- CharLeft_Comment.text=tostring(1000-StringLenInputChn)
                end
            
                StringLenInputChn=0
                -- reset count
                if(string.len(txt)>1000)then
                    print(string.len(txt))
                    -- print(CharLeft.text.." charavters left")
                    txt=string.sub(txt, 1, 1000)
                    event.target.text=txt
                    comment_Text=txt
                else
                    comment_Text=txt
                end
                print("Comment_Comment_Text: "..comment_Text)
                print( event.text )
            end
        end     
    end
---------------------------------handle text input--------------------------


local function CreateCommentBtn( event )
	if event.phase=="began" then 
	    display.getCurrentStage():setFocus(event.target)
	elseif event.phase=="ended" then 
	    print("create comment")
	    display.getCurrentStage():setFocus(nil)
	    if event.target.name=="confirm" then
	    	if string.gsub(comment_Text," ","")~="" then 
	        	M.callback( comment_Text )
	        	for i=1,#commentTempObj do 
		            display.remove(commentTempObj[i])
		        end
		        commentTempObj={}
	        end 

	    elseif event.target.name=="cancel" then 
	        for i=1,#commentTempObj do 
	            display.remove(commentTempObj[i])
	        end
	        commentTempObj={}
	        M.callback( false )
	        
	    end 
	end 
	return true 
end


function M.createMessageBox(sceneGroup,title,listener)

	if ( listener and type(listener) == "function" ) then
        M.callback = listener
    else
        error( "No callback function listed" )
    end
	--dark background 
	commentTempObj[1]=display.newRect(0,0,MyData.width,MyData.height)
	commentTempObj[1].anchorY=0
	commentTempObj[1].anchorX=0
	commentTempObj[1]:setFillColor(0,0,0,0.6)
	commentTempObj[1]:addEventListener("touch",function()  print("cant go throught ")    return true end )
	commentTempObj[1]:addEventListener("tap",function()  print("cant go throught ") return true end )
	sceneGroup:insert(commentTempObj[1])

	--white container 
	commentTempObj[2]=display.newRoundedRect(0,0,MyData.width*0.9,MyData.height*0.25,MyData.roundedEdge)
	commentTempObj[2].x=MyData.width*0.5
	commentTempObj[2].y=MyData.height*0.3
	commentTempObj[2]:setFillColor(1,1,1)
	sceneGroup:insert(commentTempObj[2])

	--confirm
	commentTempObj[3] = widget.newButton(
		{
		    label="confirm",
		    font=MyData.textFont,
		    fontSize=MyData.midfont,
		    labelColor={default={1,1,1},over={0,0,0}},
		    shape="rectangle",
		    width=commentTempObj[2].width*0.5,
		    height=commentTempObj[2].height*0.25,
		    fillColor={default={38/255,38/255,38/255,1},over={38/255,38/255,38/255,0.5}},
		    onEvent = CreateCommentBtn
		}
	)
	commentTempObj[3].anchorX=1
	commentTempObj[3].anchorY=1
	commentTempObj[3].x=commentTempObj[2].x
	commentTempObj[3].y=commentTempObj[2].y+commentTempObj[2].height*0.5
	commentTempObj[3].name="confirm"
	sceneGroup:insert(commentTempObj[3])

	--cancel 
	commentTempObj[4] = widget.newButton(
		{
		    label="cancel",
		    font=MyData.textFont,
		    fontSize=MyData.midfont,
		    labelColor={default={1,1,1},over={0,0,0}},
		    shape="rectangle",
		    width=commentTempObj[2].width*0.5,
		    height=commentTempObj[2].height*0.25,
		    fillColor={default={38/255,38/255,38/255,1},over={38/255,38/255,38/255,0.5}},
		    onEvent = CreateCommentBtn
		}
	)
	commentTempObj[4].anchorX=0
	commentTempObj[4].anchorY=1
	commentTempObj[4].x=commentTempObj[2].x
	commentTempObj[4].y=commentTempObj[2].y+commentTempObj[2].height*0.5
	commentTempObj[4].name="cancel"
	sceneGroup:insert(commentTempObj[4])

	--text input field 
	commentTempObj[5] = native.newTextField(commentTempObj[2].x, 
											commentTempObj[2].y*0.9, 
											commentTempObj[2].width*0.9, 
											MyData.height*0.06 )
	commentTempObj[5].font = native.newFont (MyData.textFont, MyData.smallfont)
	commentTempObj[5].isFontSizeScaled = true
	commentTempObj[5].align = "left"
	commentTempObj[5].size = smallfont
	commentTempObj[5].inputType = "comment"
	commentTempObj[5].placeholder = title
	commentTempObj[5].id="comment"
	commentTempObj[5]:addEventListener("userInput", handleTextField(function() return handleTextField end ) )
	commentTempObj[5]:setReturnKey( "done" )
	commentTempObj[5]:resizeFontToFitHeight()
	sceneGroup:insert(commentTempObj[5])

end


function M.createMessageBoxWeb(sceneGroup,title,listener)

	if ( listener and type(listener) == "function" ) then
        M.callback = listener
    else
        error( "No callback function listed" )
    end
	--dark background 
	commentTempObj[1]=display.newRect(0,0,MyData.width,MyData.height)
	commentTempObj[1].anchorY=0
	commentTempObj[1].anchorX=0
	commentTempObj[1]:setFillColor(0,0,0,0.6)
	commentTempObj[1]:addEventListener("touch",function()  print("cant go throught ")    return true end )
	commentTempObj[1]:addEventListener("tap",function()  print("cant go throught ") return true end )
	-- sceneGroup:insert(commentTempObj[1])

	--white container 
	commentTempObj[2]=display.newRoundedRect(0,0,MyData.width*0.9,MyData.height*0.25,MyData.roundedEdge)
	commentTempObj[2].x=MyData.width*0.5
	commentTempObj[2].y=MyData.height*0.3
	commentTempObj[2]:setFillColor(1,1,1)
	-- sceneGroup:insert(commentTempObj[2])

	--confirm
	commentTempObj[3] = widget.newButton(
		{
		    label="确定",
		    font=MyData.textFont,
		    fontSize=MyData.midfont,
		    labelColor={default={1,1,1},over={0,0,0}},
		    -- width = MyData.width*0.1,
		    -- height = MyData.width*0.1,
		    shape="rectangle",
		    width=commentTempObj[2].width*0.5,
		    height=commentTempObj[2].height*0.25,
		    fillColor={default={38/255,38/255,38/255,1},over={38/255,38/255,38/255,0.5}},
		    -- defaultFile = "Assets/reply_over.png",
		    -- overFile = "Assets/reply_down.png",
		    -- label = "button",
		    onEvent = CreateCommentBtn
		}
	)
	commentTempObj[3].anchorX=1
	commentTempObj[3].anchorY=1
	commentTempObj[3].x=commentTempObj[2].x
	commentTempObj[3].y=commentTempObj[2].y+commentTempObj[2].height*0.5
	commentTempObj[3].name="confirm"
	-- sceneGroup:insert(commentTempObj[3])

	--cancel 
	commentTempObj[4] = widget.newButton(
		{
		    label="取消",
		    font=MyData.textFont,
		    fontSize=MyData.midfont,
		    labelColor={default={1,1,1},over={0,0,0}},
		    -- width = MyData.width*0.1,
		    -- height = MyData.width*0.1,
		    shape="rectangle",
		    width=commentTempObj[2].width*0.5,
		    height=commentTempObj[2].height*0.25,
		    fillColor={default={38/255,38/255,38/255,1},over={38/255,38/255,38/255,0.5}},
		    -- defaultFile = "Assets/reply_over.png",
		    -- overFile = "Assets/reply_down.png",
		    -- label = "button",
		    onEvent = CreateCommentBtn
		}
	)
	commentTempObj[4].anchorX=0
	commentTempObj[4].anchorY=1
	commentTempObj[4].x=commentTempObj[2].x
	commentTempObj[4].y=commentTempObj[2].y+commentTempObj[2].height*0.5
	commentTempObj[4].name="cancel"
	-- sceneGroup:insert(commentTempObj[4])

	--text input field 
	commentTempObj[5] = native.newTextField(commentTempObj[2].x, commentTempObj[2].y*0.9, commentTempObj[2].width*0.9, MyData.height*0.06 )
	commentTempObj[5].font = native.newFont (MyData.textFont, MyData.smallfont)
	commentTempObj[5].isFontSizeScaled = true
	commentTempObj[5].align = "left"
	commentTempObj[5].size = smallfont
	    -- Email:resizeMyData.HeightToFitFont()
	commentTempObj[5].inputType = "comment"
	commentTempObj[5].placeholder = title
	commentTempObj[5].id="comment"
	commentTempObj[5]:addEventListener("userInput", handleTextField(function() return handleTextField end ) )
	    --native.setKeyboardFocus( email )
	commentTempObj[5]:setReturnKey( "done" )
	commentTempObj[5]:resizeFontToFitHeight()
	-- sceneGroup:insert(commentTempObj[5])

end

return M
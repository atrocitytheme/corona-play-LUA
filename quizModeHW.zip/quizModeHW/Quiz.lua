-----------------------------------------------------------------------------------------
----todo....add countdown.
-- menu.lua
--TODO 
--when user update his profile pic, change name of the avatar file.
--
------------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local MyData = require( "myData" )
local widget = require("widget")
local json=require("json")
local mod_randomWord=require("mod_randomWord")

local sceneGroup,topBanner,BannerNewsName,background
local backButton,refreshButton,statusBar,scrollView
local word
local answers={}
local answerText={}

local function getRandomWordAndDef( ... )
	return mod_randomWord.randomWord()
end

local Cards={}

local function newWord( )
	local wordDef=getRandomWordAndDef()
	word.text=wordDef[math.random(1,4)].word
	for i=1,4 do 
		--change color back 
		answers[i]:setFillColor((82-i*10)/255,(192-i*10)/255,(169-i*10)/255)

		--update the new text 
		answerText[i].text="( "..wordDef[i].wordtype.." ) "..wordDef[i].definition

		if answerText[i].height>MyData.QuizCardHeight*0.6/4 then 
			--if text is too long, set answer to text height 
			--and add mydata.height*0.06 to make sure it has 
			--some space for text
			answers[i].height=answerText[i].height+MyData.height*0.06
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			end
		else 
			answers[i].height=MyData.QuizCardHeight*0.6/4
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			end
		end

		answers[i].text=answerText[i]
		answers[i].correctWord=wordDef[i].word
	end 
end

local function putBack()
	newWord()
	transition.to(Cards[1],{time=300,alpha=1,rotation=0,transition=easing.outExpo})
	transition.to(word,{alpha=1,time=400})
	transition.to(scrollView,{alpha=1,time=400})
	for i=1,4 do 
		transition.to(answers[i],{alpha=1,time=400})
		transition.to(answerText[i],{alpha=1,time=400})
	end 
	Cards[1].x=MyData.width*0.5
	Cards[1].y=MyData.height*0.5+MyData.TopBannerHeight/2+MyData.StatusBarHeight
end

local function newWordCardTransition( ... )
	--hide everything 
	transition.to(word,{alpha=0,time=300})
	transition.to(scrollView,{alpha=0,time=300})
	for i=1,4 do 
		transition.to(answers[i],{alpha=0,time=300})
		transition.to(answerText[i],{alpha=0,time=300})
	end 
	transition.to(Cards[1],{alpha=0,x=MyData.width,y=MyData.height,rotation=45,transition=easing.outExpo,onComplete=putBack})

end


local function answersTouch( event )
	print(json.encode(scrollView))
	if event.phase=="began" then
		print("touch button") 
		event.target.alpha=0.5 
	elseif event.phase == "moved" then -- Check if you moved your finger while touching
        local dx = math.abs( event.x - event.xStart ) -- Get the x-transition of the touch-input
        local dy = math.abs( event.y - event.yStart ) -- Get the y-transition of the touch-input
        if dx > 5 or dy > 5 then
           	event.target.alpha=1
            -- display.getCurrentStage():setFocus( nil )
            -- event.target.isFocus = false                 
            -- event.target = scrollView._view
            event.phase = "began"
            -- scrollView._view.touch( scrollView._view, event )
            scrollView:takeFocus( event ) -- the above lines fake takeFocus()
        end
    elseif event.phase=="ended" or event.phase=="cancelled" then
    	print(event.target.correctWord.."   "..word.text) 
    	if event.target.correctWord==word.text then 
    		print("right ")
    		event.target:setFillColor( 100/255,255/255,100/255 )
    		newWordCardTransition()
    	else 
    		print("wrong")
    		--if it is wrong, show the correct word
    		event.target.text.text="---- "..event.target.correctWord.." ---- \n  "..event.target.text.text
    		event.target:setFillColor(255/255,100/255,100/255)
    	end 
    	event.target.alpha=1 	
    end
    return true
end


local function createCard( ... )
	for i=1,3 do 
		Cards[i]=display.newRoundedRect( sceneGroup,0,0,0,0,MyData.roundedEdge )
		Cards[i].x=MyData.width*0.5-(i-1)*(MyData.QuizCardWidth*0.02)
		Cards[i].y=MyData.height*0.5+MyData.TopBannerHeight/2+MyData.StatusBarHeight-(i-1)*(MyData.QuizCardWidth*0.02)
		Cards[i].anchorX=0.5
		Cards[i].anchorY=0.5
		Cards[i].width=MyData.QuizCardWidth
		Cards[i].height=MyData.QuizCardHeight
		Cards[i]:setFillColor( (255-(i-1)*50)/255,(255-(i-1)*50)/255,(255-(i-1)*50)/255)
		Cards[i]:toBack()
		background:toBack( )
	end 


	local option={
		text="Hello",
		width=MyData.QuizCardWidth*0.8,
		-- height=MyData.QuizCardHeight,
		align="center",
		font=MyData.textFont,
		fontSize=MyData.largefont
	}
	word=display.newText(option)
	word.x=MyData.width*0.5
	word.y=MyData.height*0.3
	word.anchorY=0.5
	word:setFillColor( 0,0,0 )
	sceneGroup:insert(word)


	scrollView = widget.newScrollView(
	    {
	        top = 0,
	        left = 0,
	        width = MyData.QuizCardWidth,
	        height = MyData.QuizCardHeight*0.6,
	        scrollWidth = MyData.QuizCardWidthi,
	        scrollHeight = MyData.height,
	        horizontalScrollDisabled=true,
	        backgroundColor = { 0.8, 0.8, 0.8,0.1 }
	        -- backgroundColor = { 0,0,0,1 }

	        -- listener = scrollListener
	    }
	)
	scrollView.x=MyData.width*0.5 
	scrollView.y=MyData.height*0.7
	sceneGroup:insert(scrollView)


	local wordDef=getRandomWordAndDef()
	word.text=wordDef[math.random(1,4)].word
	for i=1,4 do 
		answers[i]=display.newRe
		ct(0,0,MyData.QuizCardWidth, MyData.QuizCardHeight*0.6/4 )
		answers[i].x=scrollView.width*0.5
		answers[i].anchorY=0
		answers[i].y=(i-1)*MyData.QuizCardHeight*0.6/4
		answers[i]:setFillColor((82-i*10)/255,(192-i*10)/255,(169-i*10)/255)
		scrollView:insert(answers[i])
		local option={
			text="( "..wordDef[i].wordtype.." ) "..wordDef[i].definition,
			width=MyData.QuizCardWidth*0.8,
			-- height=MyData.QuizCardHeight,
			align="center",
			font=MyData.textFont,
			fontSize=MyData.midfont
		}
		answerText[i]=display.newText(option)
		answerText[i].x=answers[i].x
		answerText[i].y=answers[i].y
		answerText[i].anchorY=0.5
		answerText[i]:setFillColor( 30/255,30/255,30/255 )
		scrollView:insert(answerText[i])

		if answerText[i].height>MyData.QuizCardHeight*0.6/4 then 
			--if text is too long, set answer to text height 
			--and add mydata.height*0.06 to make sure it has 
			--some space for text
			answers[i].height=answerText[i].height+MyData.height*0.06
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			end
		else 
			answers[i].height=MyData.QuizCardHeight*0.6/4
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			end
		end

		answers[i]:addEventListener( "touch", answersTouch )
		answers[i].text=answerText[i]
		answers[i].correctWord=wordDef[i].word
	end 
end


local function buttonTouch( event )
    if event.phase=="ended" then 
        if event.target.name=="back" then 
            -- composer.gotoScene( "Home_V1","iosSlideRight",350 )
            composer.gotoScene( "Home","fade",350 )
        elseif event.target.name=="next" then 
        	newWordCardTransition()
        end 
    end
end

local function createTopNavBar( ... )
	statusBar=display.newRect(0,0,MyData.width,MyData.StatusBarHeight)
    statusBar.anchorY=0
    statusBar.y=0
    statusBar.x=MyData.width*0.5
    statusBar:setFillColor(255/255,255/255,255/255)
    sceneGroup:insert(statusBar)

    topBanner=display.newRect(0,0,MyData.width,MyData.TopBannerHeight)
    topBanner.anchorY=0
    topBanner.y=MyData.StatusBarHeight
    topBanner.x=MyData.width*0.5
    topBanner:setFillColor(82/255,192/255,169/255)
    sceneGroup:insert(topBanner)

    local textOp={
            text="Quiz",
            x=0,
            width=MyData.width*0.6,
            -- height=row.height*0.5,
            font=MyData.textFont,
            align="center",
            fontSize=MyData.bigfont,
        }


    BannerNewsName=display.newText(textOp)
    BannerNewsName:setFillColor(1,1,1)
    BannerNewsName.anchorX=0.5
    BannerNewsName.x=MyData.width*0.5
    BannerNewsName.anchorY=0.5
    BannerNewsName.y=topBanner.y+topBanner.height*0.5
    sceneGroup:insert(BannerNewsName)

    backButton=widget.newButton( 
        {
            label="Back",
            fontSize=MyData.midfont,
            font=MyData.textFont,
            width=MyData.TopBannerHeight,
            height=MyData.TopBannerHeight,
            fillColor={default={1,1,1},over={0,0,1}},
            labelColor={default={1,1,1},over={0.2,0.2,0.2}},
            onEvent=buttonTouch
        }
     )  
    backButton.x=MyData.TopBannerHeight*0.5 
    backButton.y=MyData.TopBannerHeight/2+MyData.StatusBarHeight 
    backButton.name="back"
    sceneGroup:insert(backButton)
    
    refreshButton=widget.newButton( 
        {
            label="Next",
            fontSize=MyData.midfont,
            font=MyData.textFont,
            width=MyData.TopBannerHeight,
            height=MyData.TopBannerHeight,
            fillColor={default={1,1,1},over={0,0,1}},
            labelColor={default={1,1,1},over={0.2,0.2,0.2}},
            onEvent=buttonTouch
        }
     )  
    refreshButton.x=MyData.width-MyData.TopBannerHeight*0.5
    refreshButton.y=MyData.TopBannerHeight/2+MyData.StatusBarHeight 
    refreshButton.name="next"
    sceneGroup:insert(refreshButton)

end

function scene:create( event )
	sceneGroup = self.view

    background=display.newRect(0,0,MyData.width,MyData.height)
    background.anchorY=0
    background.y=0
    background.x=MyData.width*0.5
    background:setFillColor(10/255,10/255,10/255)
    sceneGroup:insert(background)


    createTopNavBar()

    createCard() 
end



function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then

		-- LevelTracker = loadsave.loadTable("LevelTracker.json", system.DocumentsDirectory)
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
		-- sceneGroup:addEventListener("touch",changeGravity)

	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen

		composer.removeScene("Quiz")
	end	
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.

end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
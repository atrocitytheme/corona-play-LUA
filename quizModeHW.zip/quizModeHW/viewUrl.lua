-----------------------------------------------------------------------------------------
----todo....add countdown.
-- menu.lua
-- plane designed by Freepik<a href="http://www.freepik.com/free-photos-vectors/light">Light vector designed by Freepik</a>
--when user has more than 0 replys, user can get most recent replys by getting 
--Reply-userid in comments table, arrange it by time, 
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

local MyData = require( "MyData" )
local widget = require "widget"
local loadsave = require ("loadsave")
local json=require("json")
local mod_inputMessage=require("mod_inputMessage")

local mod_menuButton=require("mod_menuButton")
local mod_searchButton=require("mod_searchButton")
local mod_searchWord=require("mod_searchWord")
-- local sqlite3Util=require("sqlite3Util")
local function hideKeyboard ()
    print("hide key board")
    native.setKeyboardFocus( nil )
end

            -- composer.hideOverlay( "slideDown", 400 )
--source side panel functions 
local BannerNewsName,webView
local searchShow=false
local sceneGroup

local function wordListener( event)
    -- body
end

local function wordCallBack( event )
    if event~=false then 
        local function callBackListener( event )
            if event.phase=="ended" then 
                print("word finished look up")
                searchShow=false 
                transition.to(webView,{height=MyData.sidePanelHeight,transition=easing.outExpo})
            end 
        end 
        mod_searchWord.searchWord(event,0.5,0.5,MyData.width*0.5,MyData.height*0.25,MyData.width*0.8,MyData.height*0.45,callBackListener)
    else 
        searchShow=false 
        transition.to(webView,{height=MyData.sidePanelHeight,transition=easing.outExpo})
    end
end


local function searchButtonListener( event )
    -- print(event)
    if event.phase=="began" then 
    elseif event.phase=="moved" then 
    elseif event.phase=="ended" then 
        if searchShow==false then 
            searchShow=true 
            transition.to(webView,{height=MyData.height*0.5,transition=easing.outExpo})
            mod_inputMessage.createMessageBoxWeb(sceneGroup,"word",wordCallBack)
        elseif searchShow==true then 
            searchShow=false 
            transition.to(webView,{height=MyData.sidePanelHeight,transition=easing.outExpo})
        end 
    end
end

local function backToHome( event )
    print(event.phase)
    if event.phase=="ended" then 
        composer.hideOverlay( "slideDown", 400 )
    end 
    return true
end

local function createTopNavBar( news )
    local topBanner=display.newRect(0,0,MyData.width,MyData.TopBannerHeight)
    topBanner.anchorY=0
    topBanner.y=MyData.StatusBarHeight
    topBanner.x=MyData.width*0.5
    topBanner:setFillColor(82/255,192/255,169/255)
    sceneGroup:insert(topBanner)

    local textOp={
            text=news,
            x=0,
            width=MyData.width*0.6,
            -- height=row.height*0.5,
            font=MyData.textFont,
            align="center",
            fontSize=MyData.bigfont,
        }


    BannerNewsName=display.newText(textOp)
    BannerNewsName:setFillColor(1,1,1)
    BannerNewsName.anchorX=0.5
    BannerNewsName.x=MyData.width*0.5
    BannerNewsName.anchorY=0.5
    BannerNewsName.y=topBanner.y+topBanner.height*0.5
    sceneGroup:insert(BannerNewsName)

    mod_searchButton.initWebView(sceneGroup,MyData.width*0.95,topBanner.y+topBanner.height*0.5,searchButtonListener)


    button=widget.newButton( {
        shape="roundedRect",
        width=MyData.TopBannerHeight,
        height=MyData.TopBannerHeight,
        label="<",
        fontSize=MyData.largefont,
        labelColor={default={1,1,1,1},over={230/255,230/255,230/255}},
        fillColor={default={1,1,0,0},over={0,0,1,0}},
        onEvent=backToHome
    } )
    button.alpha=1
    button.isHitTestable=true   
    button.anchorX=0
    button.x=0
    button.y=BannerNewsName.y
    sceneGroup:insert(button)


end

function scene:create( event )
	sceneGroup = self.view
    local url=event.params.url
    local news=event.params.news

    local bg=display.newRect(sceneGroup,MyData.width*0.5,MyData.height*0.5,MyData.width,MyData.height)



    local function webListener( event )
        if event.url then
            print( "You are visiting: " .. event.url )
        end
      
        if event.type then
            print( "The event.type is " .. event.type ) -- print the type of request
        end
      
        if event.errorCode then
            native.showAlert( "Error!", event.errorMessage, { "OK" } )
        end
    end
      
    webView = native.newWebView( 0,0, MyData.width, MyData.sidePanelHeight )
    webView.x=MyData.width*0.5
    webView.anchorY=1
    webView.y=MyData.height
    webView:request( url )
    sceneGroup:insert(webView)
      
    -- webView:addEventListener( "urlRequest", webListener )

    createTopNavBar(news)

	
end



function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		local loadsave = require ("loadsave")

		-- LevelTracker = loadsave.loadTable("LevelTracker.json", system.DocumentsDirectory)
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
		-- sceneGroup:addEventListener("touch",changeGravity)
        -- createBlurGroup()

	end	
end

function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase
    local parent = event.parent  --reference to the parent scene object

    if ( phase == "will" ) then
        -- Call the "resumeGame()" function in the parent scene
        parent:resumeGame()
    end

    --composer.hideOverlay( "fade", 400 )

end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
    package.loaded[MyData]=nil
    MyData=nil

    package.loaded[widget]=nil
    widget=nil

    package.loaded[loadsave]=nil
    loadsave=nil

    package.loaded[mod_inputMessage]=nil
    mod_inputMessage=nil

    package.loaded[json]=nil
    json=nil

    package.loaded[mod_menuButton]=nil
    mod_menuButton=nil

    package.loaded[mod_searchButton]=nil
    mod_searchButton=nil
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
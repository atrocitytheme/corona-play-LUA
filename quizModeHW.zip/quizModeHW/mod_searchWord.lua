local M = {}
	local sqlite3 = require ( "sqlite3" )
	local json = require ( "json" )
	local Util=require("Util")
	local widget=require("widget")
    local MyData = require("myData")
	M.vocab={}
	M.typeTable={}
	M.defTable={}
	M.line={}


    local function scrollListener( event )
 
        local phase = event.phase
        if ( phase == "began" ) then print( "Scroll view was touched" )
        elseif ( phase == "moved" ) then print( "Scroll view was moved" )
        elseif ( phase == "ended" ) then print( "Scroll view was released" )
        end
         
            -- In the event a scroll limit is reached...
        if ( event.limitReached ) then
            if ( event.direction == "up" ) then print( "Reached bottom limit" )
            elseif ( event.direction == "down" ) then print( "Reached top limit" )
            elseif ( event.direction == "left" ) then print( "Reached right limit" )
            elseif ( event.direction == "right" ) then print( "Reached left limit" )
            end
        end
         
        return true
    end

    local overlay, scrollView, closeButton,scrollBG

    local function closeButtonEvent(event)
        if event.phase=="ended" then 
            display.remove(overlay)
            display.remove(scrollView)
            display.remove(closeButton)
            display.remove(scrollBG)
            M.vocab={}
            M.typeTable={}
            M.defTable={}
            M.line={}
            M.callback(event)
        end 
    end

    local function createDefScroll( table,anchorX,anchorY,x,y,width,height)
        -- Create the widget

        overlay=display.newRect(0,0,MyData.width,MyData.height)
        overlay.anchorY=0
        overlay.anchorX=0
        overlay:setFillColor(0,0,0,0.6)
        overlay:addEventListener("touch",function()  print("cant go throught ")    return true end )
        overlay:addEventListener("tap",function()  print("cant go throught ") return true end )

        scrollBG=display.newRoundedRect(x,y,width,height,MyData.roundedEdge )

        scrollView = widget.newScrollView(
            {
                top = 0,
                left = 0,
                width = width,
                height = height,
                horizontalScrollDisabled=true,
                scrollWidth = MyData.width*0.8,
                scrollHeight = MyData.height*0.7,
                hideBackground=true,
                listener = scrollListener
            }
        )

        scrollView.anchorX=anchorX
        scrollView.anchorY=anchorY
        scrollView.x=x
        scrollView.y=y

        closeButton=widget.newButton( {
                shape="circle",
                radius=MyData.width*0.06,
                label="X",
                fontSize=MyData.largefont,
                labelColor={default={138/255,138/255,138/255},over={100/255,100/255,100/255}},
                fillColor={default={255/255,255/255,255/255},over={240/255,240/255,240/255}},
                onEvent=closeButtonEvent
            } )
        closeButton.x=scrollView.x-scrollView.width/2
        closeButton.y=scrollView.y-scrollView.height/2

        --now render text 

        for i=1,#table do 
            local textOp={
                text=table[i].word,
                x=0,
                width=MyData.width*0.6,
                -- height=row.height*0.5,
                font=textFont,
                align="left",
                fontSize=MyData.largefont,
            }


            M.vocab[#M.vocab+1]=display.newText(textOp)
            M.vocab[#M.vocab]:setFillColor(0,0,0)
            M.vocab[#M.vocab].anchorX=0
            M.vocab[#M.vocab].x=scrollView.width*0.1
            M.vocab[#M.vocab].anchorY=0.5
            if #M.line==0 then 
                M.vocab[#M.vocab].y=scrollView.height*0.1
            else 
                M.vocab[#M.vocab].y=M.line[#M.line].y+MyData.height*0.1
            end 
            scrollView:insert(M.vocab[#M.vocab])

            local textOp={
                text=table[i].wordtype,
                x=0,
                width=MyData.width*0.6,
                -- height=row.height*0.5,
                font=textFont,
                align="right",
                fontSize=MyData.midfont,
            }


            M.typeTable[#M.typeTable+1]=display.newText(textOp)
            M.typeTable[#M.typeTable]:setFillColor(0,0,0)
            M.typeTable[#M.typeTable].anchorX=1
            M.typeTable[#M.typeTable].x=scrollView.width*0.9
            M.typeTable[#M.typeTable].anchorY=0.5
            if #M.line==0 then 
                M.typeTable[#M.typeTable].y=scrollView.height*0.1
            else 
                M.typeTable[#M.typeTable].y=M.line[#M.line].y+MyData.height*0.1
            end 
            scrollView:insert(M.typeTable[#M.typeTable])


            local textOp={
                text=table[i].definition,
                x=0,
                width=MyData.width*0.75,
                -- height=row.height*0.5,
                font=textFont,
                align="left",
                fontSize=MyData.midfont,
            }


            M.defTable[#M.defTable+1]=display.newText(textOp)
            M.defTable[#M.defTable]:setFillColor(0,0,0)
            M.defTable[#M.defTable].anchorX=0.5
            M.defTable[#M.defTable].x=scrollView.width*0.5
            M.defTable[#M.defTable].anchorY=0
            if #M.line==0 then 
                 M.defTable[#M.defTable].y=scrollView.height*0.15
            else 
                 M.defTable[#M.defTable].y=M.line[#M.line].y+MyData.height*0.13
            end 
            scrollView:insert(M.defTable[#M.defTable])


            M.line[#M.line+1]=display.newLine(scrollView.width*0.05,M.defTable[#M.defTable].y+M.defTable[#M.defTable].height,scrollView.width*0.95,M.defTable[#M.defTable].y+M.defTable[#M.defTable].height)
            M.line[#M.line]:setStrokeColor( 0,0,0 )
            M.line[#M.line].strokeWidth=2
            scrollView:insert(M.line[#M.line])

        end 

    end



function M.searchWord(word,anchorX,anchorY,x,y,width,height,listener)

	if ( listener and type(listener) == "function" ) then
        M.callback = listener
    else
        error( "No callback function listed" )
    end

        local path = system.pathForFile( "entries.db", system.DocumentsDirectory )
        db = sqlite3.open( path ) 
        print( path )
            
        word = string.lower(word)
        --local cmd = "SELECT * FROM theWords where field1='" .. word .. "'"
        local cmd = "SELECT * FROM entries WHERE word LIKE '" .. word .. "'"

        local defTable={}
        for row in db:nrows(cmd) do
            defTable[#defTable+1]=row
        end


        createDefScroll(defTable,anchorX,anchorY,x,y,width,height)

        db:close()

end

return M
-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local loadsave = require("loadsave")




local composer = require("composer")
composer.gotoScene( "Home" , "slideUp", 100 )
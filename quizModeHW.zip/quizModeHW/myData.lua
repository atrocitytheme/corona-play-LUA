local M={}

M.roundedEdge=display.contentHeight*0.01
M.textFont=native.systemFont
M.height = display.contentHeight
M.width = display.contentWidth
M.centerx = display.contentCenterX
M.centery = display.contentCenterY
M.largefont = display.contentWidth*0.067
M.bigfont = display.contentWidth*0.053
M.midfont = display.contentWidth*0.04
M.smallfont = display.contentWidth*0.032
M.titlefont=display.contentHeight*0.08
M.StatusBarHeight=display.topStatusBarContentHeight
M.TopBannerHeight=display.contentWidth*0.134
M.BoardHeight=display.contentWidth*0.05
M.BtnHeight=display.contentWidth*0.1
M.PicRowHeight=display.contentWidth
M.TextRowHeight=display.contentWidth*0.134
M.sidePanelWidth=M.width*0.8
M.sidePanelHeight=M.height-M.StatusBarHeight-M.TopBannerHeight
M.sidePanelRowHeight=display.contentWidth*0.134
M.newsRowHeight=M.width
M.articleEndpoint="https://newsapi.org/v1/articles?source="
M.source=""
M.newsApiKey="&apiKey=dcc2345feff6405d8adf41a941c71b62"
M.newsSources="https://newsapi.org/v1/sources?language=en"


M.QuizCardWidth=M.width*0.9
M.QuizCardHeight=(M.height-M.StatusBarHeight-M.TopBannerHeight)*0.95
return M



-- math.randomseed( os.time() )
-- local function shuffleTable( t )
--     local rand = math.random 
--     assert( t, "shuffleTable() expected a table, got nil" )
--     local iterations = #t
--     local j
    
--     for i = iterations, 2, -1 do
--         j = rand(i)
--         t[i], t[j] = t[j], t[i]
--     end
-- end
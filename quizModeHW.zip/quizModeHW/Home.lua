local composer=require("composer")
local scene=composer.newScene()
local myData = require("myData")
local json = require("json")
local category = {"boys", "girls"}
local newsApi = require("newsAPI")
local widget = require("widget")
local Util = require("Until")
local loadsave = require("loadsave")
local viewURL = require("viewURL")
local sceneGroup
local loading,BannerNewsName,sidePanel,sidePanelObj
local count = 0
local tableView
local btn
local paint = {
            type = "gradient",
            color1 = { 0, 0, 0, 0},
            color2 = { 18/255, 28/255, 38/255, 0.7 },
            direction = "down"
        }
local mod_menuButton = require("mod_menuButton")
local mod_searchButton = require("mod_searchButton")
local mod_inputMessage = require("mod_inputMessage")
local mod_searchWord = require("mod_searchWord")
local function menuButtonListener(event)
    print(event)
    if (event == true) then
        transition.to(sidePanel, {x=myData.width*0, transition = easing.outExpo, time=300})
    elseif event == false then
         transition.to(sidePanel, {x=-myData.width, time=300})
    end
end

local function onRowTouch(event)
    local phase = event.phase
    local row = event.row
    local params = event.row.params

    if "swipeRight" == phase then
    elseif "swipeLeft" == phase then
    elseif "tap" == phase then
    elseif "press" == phase then
        print("press row with id: ", row.id)
    elseif "cancelled" == phase then
        print("cancelled event on row with indexL ", row.index)
    elseif "release" == phase then
        print("released row..")
        local options = {
        isModal = true,
        effect = "fromBottom",
        time = 400, 
        params = {
            url = event.row.params.url,
            news = BannerNewsName.text
        }
    }
        composer.showOverlay("viewURL", options)

    end
    return true
end

local function scrollListener(event)
    local phase = event.phase
    if(phase == "began") then
    elseif(phase == "moved") then
    elseif(phase == "ended") then
    end

    if(event.limitReached) then
        if(event.direction == "up") then print("Reached bottom limit")
        elseif(event.direction == "down") then print("Reached top limit")
        elseif(event.direction == "left") then print("Reached right limit")
        elseif(event.direction == "right") then print("Reached left limit")
        end
    end
    return true
end

local function onRowRenderSource( event )
    local row = event.row
    local params = event.row.params
    local rowHeight = row.contentHeight
    local rowWidth = row.contentWidth

    local name=params.name
    local id=params.id
    local category=params.category
    local small=params.small
    local index=params.index  
if(index ~= nil) then


    if row.isCategory==false then 
        --creating post image
        local checkPostPic=Util.doesFileExist(string.sub(small,22,string.len(small)),system.CachesDirectory)
        print("does post pic exist.."..tostring(checkPostPic).."  "..string.sub(small,22,string.len(small)))
    if checkPostPic==false then 
        local function networkListener( event )
            if ( event.isError ) then
                print( "Network error - download failed" )
                elseif ( event.phase == "began" ) then
                    print( "Progress Phase: began" )
                elseif ( event.phase == "ended" ) then
                    print( "Displaying response image file" )
                    local rowIndex=sidePanelObj[2]:getRowAtIndex( index )

                    --make sure when the image is downloaded 
                    --it is inserted to the row that is currently still visible
                    if rowIndex~=nil then 
                        row.postPic = display.newImage(string.sub(small,22,string.len(small)),system.CachesDirectory)
                        row.postPic.anchorX=0
                        row.postPic.anchorY=0.5
                        row.postPic.x=row.width*0.1
                        row.postPic.y=row.height*0.5
                        -- row.postPic.fill=PostPic
                        row:insert( row.postPic  ) 

                        print(row.width.." "..row.height)
                        Util.fitImage( row.postPic, rowHeight,rowHeight, true )


                        print(name.."  asd")
                        

                        

                    else 
                        print("!!!!!!!!!!!!!!!source row not in view")
                    end
                end
            end

            local params = {}
            params.progress = true
            -- print("string.sub(small,11,string.len(small)).."..string.sub(small,22,string.len(small)))
            network.download(
                small,
                "GET",
                networkListener,
                params,
                string.sub(small,22,string.len(small)),
                system.CachesDirectory
            )
        else 
           -- already exist 
           
            row.postPic = display.newImage(string.sub(small,22,string.len(small)),system.CachesDirectory) 
            row.postPic.anchorX=0
            row.postPic.anchorY=0.5
            row.postPic.x=row.width*0.1
            row.postPic.y=row.height*0.5
            -- row.postPic.fill=PostPic
            row:insert( row.postPic  ) 

            print(row.width.." "..row.height)
            Util.fitImage( row.postPic, rowHeight,rowHeight, true )
                print(name.."  asd")


                row.postText = display.newText(name,row.width*0.8,row.height*0.5,row.width*0.4,row.height,native.systemFont, myData.bigfont)
                row.postText.anchorX = 1
                row.postText.anchorY = 0.5
                row.postText:setFillColor(0,0,0)
                row:insert(row.postText)
        end 


        

        row.line=display.newRect(row.width*0.5,row.height,row.width,row.height*0.01)
        row.line.anchorY=1
        row.line:setFillColor(0,0,0,0.5)
        row:insert(row.line)
     end

     elseif(id == "Hangman") then 
            row.postPic = display.newImage("hangman/1.png")
            row.postPic.anchorX=0
            row.postPic.anchorY=0.5
            row.postPic.x=row.width*0.1
            row.postPic.y=row.height*0.5
            -- row.postPic.fill=PostPic
            row:insert( row.postPic  ) 

            print(row.width.." "..row.height)
            Util.fitImage( row.postPic, rowHeight,rowHeight, true )


                row.postText = display.newText(id,row.width*0.8,row.height*0.5,row.width*0.4,row.height,native.systemFont, myData.bigfont)
                row.postText.anchorX = 1
                row.postText.anchorY = 0.5
                row.postText:setFillColor(1,0,0)
                row:insert(row.postText) 

        row.line=display.newRect(row.width*0.5,row.height,row.width,row.height*0.01)
        row.line.anchorY=1
        row.line:setFillColor(0,0,0,0.5)
        row:insert(row.line)



    elseif(id == "Learn") then 
    row.postPic = display.newImage("asset/3.png")
            row.postPic.anchorX=0
            row.postPic.anchorY=0.5
            row.postPic.x=row.width*0.1
            row.postPic.y=row.height*0.5
            -- row.postPic.fill=PostPic
            row:insert( row.postPic  ) 

            print(row.width.." "..row.height)
            Util.fitImage( row.postPic, rowHeight,rowHeight, true )


                row.postText = display.newText(id,row.width*0.8,row.height*0.5,row.width*0.4,row.height,native.systemFont, myData.bigfont)
                row.postText.anchorX = 1
                row.postText.anchorY = 0.5
                row.postText:setFillColor(1,0,0)
                row:insert(row.postText) 

        row.line=display.newRect(row.width*0.5,row.height,row.width,row.height*0.01)
        row.line.anchorY=1
        row.line:setFillColor(0,0,0,0.5)
        row:insert(row.line)

        elseif(id == "Quiz") then 
            row.postPic = display.newImage("asset/2.png")
            row.postPic.anchorX=0
            row.postPic.anchorY=0.5
            row.postPic.x=row.width*0.1
            row.postPic.y=row.height*0.5
            -- row.postPic.fill=PostPic
            row:insert( row.postPic  ) 

            print(row.width.." "..row.height)
            Util.fitImage( row.postPic, rowHeight,rowHeight, true )


                row.postText = display.newText(id,row.width*0.8,row.height*0.5,row.width*0.4,row.height,native.systemFont, myData.bigfont)
                row.postText.anchorX = 1
                row.postText.anchorY = 0.5
                row.postText:setFillColor(1,0,0)
                row:insert(row.postText) 

        row.line=display.newRect(row.width*0.5,row.height,row.width,row.height*0.01)
        row.line.anchorY=1
        row.line:setFillColor(0,0,0,0.5)
        row:insert(row.line)
    elseif(id == "Source") then
        row.postPic = display.newImage("asset/1.png")
            row.postPic.anchorX=0
            row.postPic.anchorY=0.5
            row.postPic.x=row.width*0.1
            row.postPic.y=row.height*0.5
            -- row.postPic.fill=PostPic
            row:insert( row.postPic  ) 

            print(row.width.." "..row.height)
            Util.fitImage( row.postPic, rowHeight,rowHeight, true )


                row.postText = display.newText(id,row.width*0.8,row.height*0.5,row.width*0.4,row.height,native.systemFont, myData.bigfont)
                row.postText.anchorX = 1
                row.postText.anchorY = 0.5
                row.postText:setFillColor(1,0,0)
                row:insert(row.postText) 

        row.line=display.newRect(row.width*0.5,row.height,row.width,row.height*0.01)
        row.line.anchorY=1
        row.line:setFillColor(0,0,0,0.5)
        row:insert(row.line)
end

end

local function renderNewsTable(inputRows)
    -- body
    tableView:deleteAllRows()
    for i=1,#inputRows.articles do 
        print("creating news")
        local isCategory 
        local rowHeight
        local rowColor

        local str="0123456789abcdefghijklmnopqrstuvwxyz"  --随机名字，使图片能够access
        local randomText=string.char(str:byte(math.random(1, #str)))..
                        string.char(str:byte(math.random(1, #str)))..
                        string.char(str:byte(math.random(1, #str)))..
                        string.char(str:byte(math.random(1, #str)))..
                        string.char(str:byte(math.random(1, #str)))..
                        string.char(str:byte(math.random(1, #str)))..
                        string.char(str:byte(math.random(1, #str)))
        local lineColor = { 0.5, 0.5, 0.5 }
        local imageUrl=false
        if inputRows.articles[i].urlToImage~=nil then 
            imageUrl=inputRows.articles[i].urlToImage
        end
        print("URL"..inputRows.articles[i].url)
        --and insert a picture row
        isCategory=false 
        rowHeight = myData.newsRowHeight
        rowColor = { default={1,1,1,0.1}, over={1,0.5,0,0.1} }

        tableView:insertRow(
            {
                isCategory = isCategory,
                rowHeight = rowHeight,
                rowColor = rowColor,
                -- lineColor = lineColor
                params = {
                    urlToImage=imageUrl,
                    description=inputRows.articles[i].description,
                    publishedAt=inputRows.articles[i].publishedAt,
                    author=inputRows.articles[i].author,
                    url=inputRows.articles[i].url,
                    title=inputRows.articles[i].title,
                    imageName=math.ceil((math.random(1,10000000)/math.random(1,1000)))..os.time()..randomText..".jpg",
                    index=i
                }

            }
        )
    end   --每当news加载时rows中内容的反应
end

local function onRowTouchSource( event )  --在左panel上点击时选定内容范围
    local phase = event.phase
    local row = event.target
    local params = event.row.params

    if "swipeRight" == phase then
     
    elseif "swipeLeft" == phase then
     
    elseif "tap" == phase then --and canTap==true
            
    elseif "press" == phase then
        print( "Pressed row with id: ", row.id )
    elseif "cancelled" == phase then
        print( "Cancelled event on row with index: ", row.index )
    elseif "release" == phase then
        print("released row")
        print(event.row.params.id)
        if(event.row.params.id ~= "Quiz" and event.row.params.id ~= "Learn" and event.row.params.id ~= "Hangman")  then
            local function listener( event )
                if event~=true then 
                    print("render news")
                    local news = loadsave.loadTable(event, system.DocumentsDirectory)
                    renderNewsTable(news)
                end 
            end
            newsApi.getPosts(listener,event.row.params.id)
            BannerNewsName.text=event.row.params.name
             

            --hide menu 
            mod_menuButton.menuShown=false 
            mod_menuButton.ThreeLine()
            transition.to(sidePanel,{x=-myData.width,time=300})
        elseif(event.row.params.id == "Learn") then
            print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@sadadzxczsa "..event.row.params.id)
            composer.gotoScene("Learn", "slideUp", 100)
        elseif(event.row.params.id == "Source") then print("Source")
        elseif(event.row.params.id == "Quiz") then 
            composer.gotoScene( "Quiz", "slideUp", 100 ) 
            print("sadadzxczsa "..event.row.params.id)
        elseif(event.row.params.id == "Hangman") then 
            composer.gotoScene( "Hangman", "slideUp", 100 ) 
            print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

        end
    end
    return true
end

local function loadRandomNews( ... )
    --load from a random source 
    local newsSource = loadsave.loadTable("newsSource.json", system.DocumentsDirectory)
    local function listener( event )
        if event~=true then 
            print("render news")
            local news = loadsave.loadTable(event, system.DocumentsDirectory)
            renderNewsTable(news)
        end 
    end
    if #newsSource.sources~=0 then 
        local random=math.random(1,#newsSource.sources)
        newsApi.getPosts(listener,newsSource.sources[random].id)
        BannerNewsName.text=newsSource.sources[random].name
    end
end



local function searchButtonListener( event )
    print(event)
    if event==true then 
        local function listener( event )
            print(event)
            if event~=false then
                local function callBackListener( event )
                    if event.phase=="ended" then 
                        print("word finished look up")
                    end 
                end 
                mod_searchWord.searchWord(event,0.5,0.5,myData.width*0.5,myData.height*0.5,myData.width*0.8,myData.height*0.7,callBackListener)
            end
        end
        mod_inputMessage.createMessageBox(sceneGroup,"word",listener)
    end
end



local function createTopNavBar( ... )
    local topBanner=display.newRect(0,0,myData.width,myData.TopBannerHeight)
    topBanner.anchorY=0
    topBanner.y=myData.StatusBarHeight
    topBanner.x=myData.width*0.5
    topBanner:setFillColor(82/255,192/255,169/255)
    sceneGroup:insert(topBanner)

    local textOp={
            text="",
            x=0,
            width=myData.width*0.6,
            -- height=row.height*0.5,
            font=myData.textFont,
            align="center",
            fontSize=myData.bigfont,
        }


    BannerNewsName=display.newText(textOp)
    BannerNewsName:setFillColor(1,1,1)
    BannerNewsName.anchorX=0.5
    BannerNewsName.x=myData.width*0.5
    BannerNewsName.anchorY=0.5
    BannerNewsName.y=topBanner.y+topBanner.height*0.5
    sceneGroup:insert(BannerNewsName)

    mod_menuButton.init(sceneGroup,myData.width*0.05,topBanner.y+topBanner.height*0.5,menuButtonListener)
    mod_searchButton.init(sceneGroup,myData.width*0.95,topBanner.y+topBanner.height*0.5,searchButtonListener)


    sidePanel=display.newGroup()
    sidePanelObj={}
    --bg
    sidePanelObj[1]=display.newRect(0,0,myData.sidePanelWidth,myData.sidePanelHeight)
    sidePanelObj[1].y=myData.TopBannerHeight+myData.StatusBarHeight
    sidePanelObj[1].x=-myData.width*0.1
    sidePanelObj[1].anchorY=0
    sidePanelObj[1].anchorX=0

    sidePanelObj[2]= widget.newTableView(
        {
            left = 0,
            top = myData.TopBannerHeight+myData.StatusBarHeight,
            height = sidePanelObj[1].height,
            width = sidePanelObj[1].width-myData.width*0.1,
            noLines=true, -- --
            hideBackground=true,
            onRowRender = onRowRenderSource,
            onRowTouch = onRowTouchSource,
            listener = scrollListenerSource,
            maxVelocity=5
        }
    )

    -- sidePanelObj[3]= widget.newTableView(
    --     {
    --         left = sidePanelObj[2].width,
    --         top = myData.TopBannerHeight+myData.StatusBarHeight,
    --         height = sidePanelObj[1].height,
    --         width = sidePanelObj[1].width-myData.width*0.1,
    --         noLines=true,
    --         hideBackground=true,
    --         onRowRender = onRowRenderSource1,
    --         onRowTouch = onRowTouchSource1,
    --         listener = scrollListenerSource,
    --         maxVelocity=5
    --     }
    -- )

    for i=1,#sidePanelObj do 
        sidePanel:insert(sidePanelObj[i])
    end
    sceneGroup:insert(sidePanel)

    sidePanel.x=0
    transition.to(sidePanel,{x=myData.width*0,transition=easing.outBack,time=500})

    
end    --    一整套banner＋navigator
   
local function renderSourceTable( ... )  --导航中的table

    local newsSource = loadsave.loadTable("newsSource.json", system.DocumentsDirectory) --装载通过file：read读取的内容
    

    sidePanelObj[2]:insertRow( --图片内容等
                {
                    isCategory = false,
                    rowHeight = myData.sidePanelRowHeight,
                    rowColor = { default={1,1,1,0.1}, over={1,0.5,0,0.1} },
                    -- lineColor = lineColor
                    params = {
                        name=nil,
                        category=false,
                        small=nil,
                        index=nil,
                        id="Learn"
                    }

                }
            )

    sidePanelObj[2]:insertRow( --图片内容等
                {
                    isCategory = false,
                    rowHeight = myData.sidePanelRowHeight,
                    rowColor = { default={1,1,1,0.1}, over={1,0.5,0,0.1} },
                    -- lineColor = lineColor
                    params = {
                        name=nil,
                        category=false,
                        small=nil,
                        index=nil,
                        id="Quiz"
                    }

                }
            )

    sidePanelObj[2]:insertRow( --图片内容等
                {
                    isCategory = false,
                    rowHeight = myData.sidePanelRowHeight,
                    rowColor = { default={1,1,1,0.1}, over={1,0.5,0,0.1} },
                    -- lineColor = lineColor
                    params = {
                        name=nil,
                        category=false,
                        small=nil,
                        index=nil,
                        id="Hangman"
                    }

                }
            )

    sidePanelObj[2]:insertRow( --图片内容等
                {
                    isCategory = true,
                    rowHeight = myData.sidePanelRowHeight,
                    rowColor = { default={100/255,255/255,150/255,0.8}, over={1,0.5,0,0.1} },
                    params = {
                        name=nil,
                        category=true,
                        small=nil,
                        index=nil,
                        id="Source"
                    }

                }
            )

    for i=1,#newsSource.sources do --详见json file
        local isCategory 
        local rowHeight
        local rowColor
        --and insert a picture row
          isCategory=false 
          rowHeight = myData.sidePanelRowHeight
          rowColor = { default={1,1,1,0.1}, over={1,0.5,0,0.1} }


            sidePanelObj[2]:insertRow( --图片内容等
                {
                    isCategory = isCategory,
                    rowHeight = rowHeight,
                    rowColor = rowColor,
                    -- lineColor = lineColor
                    params = {
                        name=newsSource.sources[i].name,
                        category=newsSource.sources[i].category,
                        small=newsSource.sources[i].urlsToLogos.small,
                        index=i,
                        id=newsSource.sources[i].id
                    }

                }
            )
    end   
end






local function sourceListener(event)--API中的calllback
    	print("call back: "..tostring(event))
    	if event == true then
    		print("start render")
    		renderSourceTable()
    		loadRandomNews()
    		display.remove(loading) --
    	elseif event == false then 
    		loading.text = "Connection Error, Click to retry"..count
    		count = count+1
    	end
end

local function downloading(row,index,urlToImage,imageName,rowWidth,rowHeight)
                local function networkListener( event )
                    -- print(json.encode(event))
                    if ( event.isError ) then
                        print( "Network error - download failed" )
                    elseif ( event.phase == "began" ) then
                        print( "Progress Phase: began" )
                    elseif ( event.phase == "ended" ) then
                        print( "Displaying response image file  "..index )
                        local rowIndex=tableView:getRowAtIndex( index )

                        --make sure when the image is downloaded 
                        --it is inserted to the row that is currently still visible
                        if rowIndex~=nil then                             
                           
                            row.postPic = display.newImage(imageName,system.TemporaryDirectory)
                            row:insert( row.postPic  ) 
                            row.postPic.anchorX=0.5
                            row.postPic.anchorY=0
                            row.postPic.x=myData.width*0.5
                            row.postPic.y=0
                            print(row.width.." "..row.height)
                            Util.fitImage( row.postPic, rowWidth,rowHeight, true )

                            --make sure the picture is at the bottom
                            row:insert(row.postShade)
                            row:insert(row.postText)
                            row:insert(row.description)
                            
                        else 
                            print("not visible") 
                        end

                        
                    end
                end

                local params = {}
                params.progress = true

                network.download(
                    urlToImage,
                    "GET",
                    networkListener,
                    params,
                    imageName,
                    system.TemporaryDirectory
                )

                print("------!   "..imageName)

end --将分配row以及下载图片全部放在一个function内部，分配row更加清晰，以免global的row变量和加载顺序不一导致系统分配row混乱

local function onRowRender( event )
    local row = event.row
    local params = event.row.params --row中的param用处
    -- Cache the row "contentWidth" and "contentHeight" because the row bounds can change as children objects are added
    local rowHeight = row.contentHeight
    local rowWidth = row.contentWidth

    local urlToImage=params.urlToImage
    local description=params.description

    local publishedAt=params.publishedAt
    local author=params.author

    local url=params.url
    local title=params.title
    local imageName=params.imageName
    local rowIndex=tableView:getRowAtIndex( index )
    local index=params.index 

    if row.isCategory==false then 
        if urlToImage~=false then 
            local checkPostPic=Util.doesFileExist(imageName,system.TemporaryDirectory)
            print("does post pic exist: "..tostring(checkPostPic).."  "..imageName)

            if checkPostPic==false then 
                downloading(row,index,urlToImage,imageName,rowWidth,rowHeight)
            else 
                --already exist 
                row.postPic = display.newImage(imageName,system.TemporaryDirectory)
                row.postPic.anchorX=0.5
                row.postPic.anchorY=0
                row.postPic.x=row.width*0.5
                row.postPic.y=0
                -- row.postPic.fill=PostPic
                row:insert( row.postPic  ) 

                -- print(row.width.." "..row.height)
                Util.fitImage( row.postPic, rowWidth,rowHeight, true )
            end 
        end

        local paint = {
            type = "gradient",
            color1 = { 0, 0, 0, 0},
            -- color2 = { 18/255, 28/255, 38/255, 0.9 },
            color2 = { 255/255, 255/255, 255/255, 0.9 },
            direction = "down"
        }

        --creating shade for text
        row.postShade=display.newRect(row.width*0.5,row.height,row.width,row.height)
        row.postShade.anchorY=1
        row.postShade.fill=paint
        row:insert(row.postShade)

        if description==nil then 
            description=""
        end
        local textOp={
            text=description,
            x=0,
            width=row.width*0.9,
            -- height=row.height*0.5,
            font=myData.textFont,
            align="left",
            fontSize=myData.midfont,
        }


        row.description=display.newText(textOp)
        row.description:setFillColor(38/255,38/255,38/255)
        row.description.anchorX=0
        row.description.x=row.width*0.05
        row.description.anchorY=1
        row.description.y=row.height*0.9
        row:insert(row.description)


        local textOp={
            text=title,
            x=0,
            width=row.width*0.9,
            -- height=row.height*0.5,
            font=myData.textFont,
            align="left",
            fontSize=myData.bigfont,
        }


        row.postText=display.newText(textOp)
        row.postText:setFillColor(0,0,0)
        row.postText.anchorX=0
        row.postText.x=row.width*0.05
        row.postText.anchorY=1
        row.postText.y=row.description.y-row.description.height-myData.width*0.01
        row:insert(row.postText)

     
    end

    -- local rowTitle = display.newText( row, "Row " .. row.index, 0, 0, nil, 14 )
    -- rowTitle:setFillColor( 0 )

    -- -- Align the label left and vertically centered
    -- rowTitle.anchorX = 0
    -- rowTitle.x = 0
    -- rowTitle.y = rowHeight * 0.5
end


local function createTableView()
	tableView= widget.newTableView(
        {
            left = 0,
            top = myData.TopBannerHeight+myData.StatusBarHeight,
            height = myData.height - myData.StatusBarHeight- myData.TopBannerHeight,
            width = myData.width,
            noLines=true,
            -- hideBackground=true,
            onRowRender = onRowRender,
            onRowTouch = onRowTouch,
            listener = scrollListener,
            maxVelocity=5
        }
    )
    sceneGroup:insert(tableView)
end



function scene:create(event)
	sceneGroup=self.view
	createTableView()
    createTopNavBar()
    newsApi.source(sourceListener)

    local function retry(...)
		newsApi.source(sourceListener) --从API处加载json
	end
	loading = display.newText("loading...",0,0,myData.textFont,myData.midfont)
	loading.x = myData.width*0.5
	loading.y = myData.height*0.2
	loading:setFillColor(0,0,0)
	sceneGroup:insert(loading)
	loading:addEventListener("touch", retry)

end


 

function scene:show(event)
	local sceneGroup=self.view
	local phase=event.phase
	if phase=="will" then 
	elseif phase =="did" then
	end
end

function scene:hide(event)
    local sceneGroup=self.view
end
   scene:addEventListener("create",scene)	 
   scene:addEventListener("show",scene)	 
   scene:addEventListener("hide",scene)	 
   scene:addEventListener("destroy",scene)	 
return scene
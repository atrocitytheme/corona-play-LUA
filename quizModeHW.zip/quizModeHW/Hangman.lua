-----------------------------------------------------------------------------------------
----todo....add countdown.
-- menu.lua
--TODO 
--when user update his profile pic, change name of the avatar file.
--
------------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local MyData = require( "myData" )
local widget = require "widget"
local loadsave = require ("loadsave")
local json=require("json")
local mod_randomWord=require("mod_randomWord")
local atoz={    "a",
                "b",
                "c",
                "d",
                "e",
                "f",
                "g",
                "h",
                "i",
                "j",
                "k",
                "l",
                "m",
                "n",
                "o",
                "p",
                "q",
                "r",
                "s",
                "t",
                "u",
                "v",
                "w",
                "x",
                "y",
                "z"
            }
local sceneGroup,topBanner,BannerNewsName
local backButton,refreshButton

local function getRandomWordAndDef( ... )

    return mod_randomWord.randomOneWord()

end



local hangman={}
local currentHangman=1
local letter={}
local line={}
local letterButton={}
local buttonText={}
local definition
local canClick=true  

local function wordToTable(word)
    local temp={}
    for i=1,string.len( word ) do 
        temp[i]=string.sub( word, i,i )
    end 
    print(json.encode(temp))
    return temp
end 
local function createHangman( )
    for i=1,9 do 
        hangman[i]=display.newImageRect( sceneGroup, "hangman/"..i..".png",MyData.height*0.3,MyData.height*0.3)
      
        hangman[i].alpha=0
        hangman[i].anchorY=0
        hangman[i].x=MyData.width*0.5
        hangman[i].y=MyData.height*0.1
        if i==1 then 
            hangman[i].alpha=1
        end 
    end   
end

local function createLines( inputTable )
    line={}
    letter={}
    for i=1,#inputTable do 
        print("create lines and letter")
        line[i]=display.newRect( sceneGroup, 0, 0, 0, 0 )
        line[i].width=MyData.width/(#inputTable+#inputTable/2)
        line[i].height=MyData.height*0.01
        line[i]:setFillColor( 0,0,0 )
        line[i].anchorX=0
        line[i].x=line[i].width/4+((i-1)*line[i].width*1.5)
        line[i].y=MyData.height*0.45

        letter[i]=display.newText( sceneGroup, inputTable[i],0,0,MyData.textFont,line[i].width)
        letter[i]:setFillColor( 0,0,0 )
        letter[i].anchorX=0
        letter[i].x=line[i].x+line[i].width*0.25
        letter[i].y=line[i].y-line[i].width*0.6
        letter[i].alpha=0 
        if string.match(inputTable[i],"%A") then 
            letter[i].alpha=1
        end 
        print(letter[i].text)
       
    end 
end

local function destroyLines( ... )
    for i=1,#line do 
       display.remove(letter[i])
       display.remove(line[i])

    end 
end


local function win( ... )
    canClick=false 
    hangman[currentHangman].alpha=0
    definition.alpha=1
end

local function die( ... )
    canClick=false 
    definition.alpha=1
    for i=1,#letter do 
        letter[i].alpha=1
    end 
end

local function checkWord( inputLetter,inputAnswer )
    -- print((letter[1].text))
    -- print(string.lower(letter[1].text))
    local exist=false 
    for i=1,#letter do 
        -- print(inputLetter.."    "..string.lower(letter[i].text).."  right word "..json.encode(inputAnswer))
        local lower=string.lower(letter[i].text)
        if (inputLetter)==lower then 
            print("correct")
            letter[i].alpha=1
            exist = true 
            --if every word is shown then 
            local count=0
            for i=1,#letter do 
                if letter[i].alpha==1 then 
                    count=count+1
                end
            end 
            if count==#letter then 
                --win and show actual word 
                print("win!!")
                win()
            end 
        else   
           
        end
    end 
    if exist==false then 
        hangman[currentHangman].alpha=0
        currentHangman=currentHangman+1
        if currentHangman<9 then 
            hangman[currentHangman].alpha=1
        elseif currentHangman==9 then 
            hangman[currentHangman].alpha=0.2
            --die and show actual word and meaning 
            print('die')
            die()
        else 
        end 
    end 
    
    return exist  
end

local function playAction( event )
    if event.phase=="began" then 
        event.target.alpha=0.5
    elseif event.phase=="ended" then 
        event.target.alpha=1
        if canClick==true then 
            local exist =checkWord(event.target.letter,event.target.answerTable)
        end 
    else
        event.target.alpha=1
    end 
    return true 
end

local function createWord( ... )
    -- body
    --under line and potential words 
    local oneWord=getRandomWordAndDef()
    local wordCount=string.len(oneWord[1].word)
    local wordTable=wordToTable(oneWord[1].word)
    print(wordCount.."  "..oneWord[1].word)
    createLines(wordTable)

    --for the phones that has longer height*0.5 than width  
    local buttonWidth=MyData.width/6
    local buttonActualWidth=MyData.width/6.5

    --for those phones that has shorter height than width 
    --ipad , iphone4, 5 
    if MyData.height*0.5/5<MyData.width/6 then 
        buttonWidth=MyData.height*0.5/5
        buttonActualWidth=MyData.height*0.5/5.5
    end 

    local gap=(MyData.width-buttonActualWidth*6)/2
    local row=1
    local col=1
    -- create the definition 
    local option ={
        text="( "..oneWord[1].wordtype.." ) "..oneWord[1].definition,
        width=MyData.QuizCardWidth*0.8,
        -- height=MyData.QuizCardHeight,
        align="center",
        font=MyData.textFont,
        fontSize=MyData.midfont
    }
    definition = display.newText(option)
    definition.x=MyData.width*0.5
    definition.y=MyData.height*0.25
    definition.alpha=0
    definition:setFillColor( 20/255,20/255,20/255 )
    sceneGroup:insert(definition)

    for i=1,26 do
        local randomRotation=math.random(-10,10) 
        letterButton[i]=display.newRoundedRect( sceneGroup, 0,0, buttonActualWidth, buttonActualWidth, MyData.width*0.01 )
        letterButton[i].anchorX=0.5
        letterButton[i].x=gap+buttonActualWidth*0.25+(col-1)*(buttonWidth)
        letterButton[i].y=MyData.height*0.55+(row-1)*(buttonWidth)
        letterButton[i]:setFillColor( 200/255,255/255,20/255 )
        letterButton[i].rotation=randomRotation
        
        buttonText[i]=display.newText(sceneGroup, atoz[i], 0,0,MyData.textFont,MyData.largefont )
        buttonText[i].anchorX=0.5
        buttonText[i].x=letterButton[i].x
        buttonText[i].y=letterButton[i].y
        buttonText[i]:setFillColor( 20/255,20/255,20/255 )
        buttonText[i].rotation=randomRotation



        col=col+1
        if col==7 then 
            col=1 
            row=row+1
        end 

        letterButton[i].answerTable=wordTable
        letterButton[i].letter=buttonText[i].text
        letterButton[i]:addEventListener( "touch", playAction )
    end 
end

local function newWord( ... )
    destroyLines()

    hangman[currentHangman].alpha=0
    currentHangman=1
    hangman[currentHangman].alpha=1

    local oneWord=getRandomWordAndDef()
    local wordCount=string.len(oneWord[1].word)
    local wordTable=wordToTable(oneWord[1].word)
    print(wordCount.."  "..oneWord[1].word)
    createLines(wordTable)

    -- create the definition 
    definition.text="( "..oneWord[1].wordtype.." ) "..oneWord[1].definition
    definition.alpha=0

    for i=1,26 do
        local randomRotation=math.random(-10,10) 
        letterButton[i].rotation=randomRotation
        buttonText[i].rotation=randomRotation

        letterButton[i].answerTable=wordTable
        letterButton[i].letter=buttonText[i].text
    end  

    --enable click after everything reloads 
    canClick=true 

end


local function buttonTouch( event )
    if event.phase=="ended" then 
        if event.target.name=="back" then 
            composer.gotoScene( "Home","slideUp",350 )
        elseif event.target.name=="more" then 
            -- newWord()
            newWord()
        end 
    end
end

local function createTopNavBar( ... )
    topBanner=display.newRect(0,0,MyData.width,MyData.TopBannerHeight)
    topBanner.anchorY=0
    topBanner.y=MyData.StatusBarHeight
    topBanner.x=MyData.width*0.5
    topBanner:setFillColor(82/255,192/255,169/255)
    sceneGroup:insert(topBanner)

    local textOp={
            text="Hangman",
            x=0,
            width=MyData.width*0.6,
            -- height=row.height*0.5,
            font=MyData.textFont,
            align="center",
            fontSize=MyData.bigfont,
        }


    BannerNewsName=display.newText(textOp)
    BannerNewsName:setFillColor(1,1,1)
    BannerNewsName.anchorX=0.5
    BannerNewsName.x=MyData.width*0.5
    BannerNewsName.anchorY=0.5
    BannerNewsName.y=topBanner.y+topBanner.height*0.5
    sceneGroup:insert(BannerNewsName)

    backButton=widget.newButton( 
        {
            label="Back",
            fontSize=MyData.midfont,
            font=MyData.textFont,
            width=MyData.TopBannerHeight,
            height=MyData.TopBannerHeight,
            fillColor={default={1,1,1},over={0,0,1}},
            labelColor={default={1,1,1},over={0.2,0.2,0.2}},
            onEvent=buttonTouch
        }
     )  
    backButton.x=MyData.TopBannerHeight*0.5 
    backButton.y=MyData.TopBannerHeight/2+MyData.StatusBarHeight 
    backButton.name="back"
    sceneGroup:insert(backButton)
    
    refreshButton=widget.newButton( 
        {
            label="New",
            fontSize=MyData.midfont,
            font=MyData.textFont,
            width=MyData.TopBannerHeight,
            height=MyData.TopBannerHeight,
            fillColor={default={1,1,1},over={0,0,1}},
            labelColor={default={1,1,1},over={0.2,0.2,0.2}},
            onEvent=buttonTouch
        }
     )  
    refreshButton.x=MyData.width-MyData.TopBannerHeight*0.8 
    refreshButton.y=MyData.TopBannerHeight/2+MyData.StatusBarHeight 
    refreshButton.name="more"
    sceneGroup:insert(refreshButton)

    -- createWords()
    createWord()
end

function scene:create( event )
	sceneGroup = self.view

    local background=display.newRect(0,0,MyData.width,MyData.height)
    background.anchorY=0
    background.y=0
    background.x=MyData.width*0.5
    background:setFillColor(255/255,255/255,255/255)
    sceneGroup:insert(background)
    createTopNavBar()
    createHangman()
end



function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then

		-- LevelTracker = loadsave.loadTable("LevelTracker.json", system.DocumentsDirectory)
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
		-- sceneGroup:addEventListener("touch",changeGravity)

	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen

		composer.removeScene("Hangman")
	end	
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.

end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene















































































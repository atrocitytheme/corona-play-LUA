local json = require ( "json" )
local MyData=require("MyData")
local mime=require("mime")
local loadsave=require("loadsave")

local function SaveDataToJson( inputJson, fileName )
    loadsave.saveTable(inputJson, fileName, system.DocumentsDirectory)
end

local M={}
    --get post according to offset value
    M.getPosts=function(listener,source)
        if ( listener and type(listener) == "function" ) then
            M.callback = listener
        else
            error( "No callback function listed" )
        end
        local function networkListener( event )
            if ( event.isError ) then
                print( "Network error!" )
                -- data=display.newText(tostring(event.status).." "..tostring(event.isReachable).."  "..tostring(event.address),0,0,textFont,30)
                -- data.x=MyData.width*0.5
                -- data.y=200
                M.callback( false )
            elseif ( event.phase == "began" ) then
                print( "Progress Phase: began" )
            elseif ( event.phase == "ended" ) then
            
                local myNewData = json.decode(event.response)
                if myNewData.status=="ok" then
                    print("saving ") 
                    SaveDataToJson(myNewData,source..".json")
                    M.callback( source..".json" )
                else 
                    M.callback(false)
                end
            end
        end

        local headers = {}

        headers["Content-Type"] = "application/x-www-form-urlencoded"
        headers["Accept-Language"] = "en-US"

        local body = ""

        local params = {}
        params.headers = headers
        params.body = body

        MyData.source=source

        print(MyData.articleEndpoint..MyData.source..MyData.newsApiKey)
        network.request(MyData.articleEndpoint..MyData.source..MyData.newsApiKey, "GET", networkListener, params )
    end


    M.source=function(listener)
        if ( listener and type(listener) == "function" ) then
            M.callback = listener
        else
            error( "No callback function listed" )
        end
        local function networkListener( event )
            if ( event.isError ) then
                print( "Network error!" )
                M.callback( false )
            elseif ( event.phase == "began" ) then
                print( "Progress Phase: began" )
            elseif ( event.phase == "ended" ) then
               
                local myNewData = json.decode(event.response)
                if myNewData.status=="ok" then 
                    SaveDataToJson(myNewData,"newsSource.json")
                    M.callback( true )
                else 
                    M.callback(false)
                end
            end
        end



        -- local function networkListener( event )
        --    if event.phase=="ended" then 
        --     print(event.response)
        -- end 
        -- end
        local headers = {}

        headers["Content-Type"] = "application/x-www-form-urlencoded"
        headers["Accept-Language"] = "en-US"

        local body = ""

        local params = {}
        params.headers = headers
        params.body = body

        network.request(MyData.newsSources, "GET", networkListener, params )
    end



return M
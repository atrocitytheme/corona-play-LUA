-----------------------------------------------------------------------------------------
----todo....add countdown.
-- menu.lua
--TODO 
--when user update his profile pic, change name of the avatar file.
--
------------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local MyData = require( "myData" )
local widget = require("widget")
local json=require("json")
local mod_randomWord=require("mod_randomWord")

local sceneGroup,topBanner,BannerNewsName,background
local backButton,refreshButton,statusBar,scrollView
local word
local answers={}
local answerText={}
local wordText = {}

local function getRandomWordAndDef( ... )
	return mod_randomWord.randomTenWord()
end

local Cards={}

local function newWord( )
	local wordDef=getRandomWordAndDef()
	word.text=wordDef[math.random(1,4)].word
	for i=1,4 do 
		--change color back 
		answers[i]:setFillColor((82-i*10)/255,(192-i*10)/255,(169-i*10)/255)

		--update the new text 
		answerText[i].text="( "..wordDef[i].wordtype.." ) "..wordDef[i].definition

		if answerText[i].height>MyData.QuizCardHeight*0.6/4 then 
			--if text is too long, set answer to text height 
			--and add mydata.height*0.06 to make sure it has 
			--some space for text
			answers[i].height=answerText[i].height+MyData.height*0.06
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			end
		else 
			answers[i].height=MyData.QuizCardHeight*0.6/4
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			end
		end

		answers[i].text=answerText[i]
		answers[i].correctWord=wordDef[i].word
	end 
end

function createWords()
	scrollView = widget.newScrollView( {
		 top = 0,
	        left = 0,
	        width = MyData.QuizCardWidth,
	        height = MyData.QuizCardHeight*0.9,
	        scrollWidth = MyData.QuizCardWidth,
	        scrollHeight = MyData.QuizCardHeight,
	        horizontalScrollDisabled=true,
	        backgroundColor = { 0.8, 0.8, 0.8,0.1 }
		} )

		scrollView.x=MyData.width*0.5 
		scrollView.y=MyData.height*0.55
		sceneGroup:insert(scrollView)

		local wordDef=getRandomWordAndDef()
		
		for i=1,10 do 
		answers[i]=display.newRoundedRect(0,0,MyData.QuizCardWidth, MyData.QuizCardHeight*0.6/4,MyData.roundedEdge )
		answers[i].x=scrollView.width*0.5
		answers[i].anchorY=0
		answers[i].y=(i-1)*MyData.QuizCardHeight*0.6/4
		answers[i]:setFillColor((82-i*10)/255,(192-i*10)/255,(169-i*10)/255)
		scrollView:insert(answers[i])

		local option={
			text= wordDef[i].word,
			width=MyData.QuizCardWidth*0.8,
			-- height=MyData.QuizCardHeight,
			align="center",
			font=MyData.textFont,
			fontSize=MyData.bigfont
		}
		wordText[i] = display.newText(option)
		wordText[i].x = answers[i].x
		wordText[i].y = 0
		wordText[i].anchorY = 1
		wordText[i]:setFillColor( 30/255, 30/255, 30/255 )
		scrollView:insert(wordText[i])

		local option={
			text="( "..wordDef[i].wordtype.." ) "..wordDef[i].definition,
			width=MyData.QuizCardWidth*0.8,
			-- height=MyData.QuizCardHeight,
			align="center",
			font=MyData.textFont,
			fontSize=MyData.midfont
		}
		answerText[i]=display.newText(option)
		answerText[i].x=answers[i].x
		answerText[i].y=answers[i].y
		answerText[i].anchorY=0
		answerText[i]:setFillColor( 30/255,30/255,30/255 )
		scrollView:insert(answerText[i])

		if answerText[i].height>MyData.QuizCardHeight*0.6/4 then 
			--if text is too long, set answer to text height 
			--and add mydata.height*0.06 to make sure it has 
			--some space for text
			answers[i].height=answerText[i].height+MyData.height*0.06
			if i==1 then 
				answers[i].y=0
				wordText[i].y = answers[i].y+answers[i].height/3-MyData.height*0.005
				answerText[i].x=answers[i].x
				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				wordText[i].y = answers[i].y+answers[i].height/3-MyData.height*0.005

				answerText[i].y=answers[i].y+answers[i].height/2
			end
		else 
			answers[i].height=MyData.QuizCardHeight*0.6/4
			if i==1 then 
				answers[i].y=0
				answerText[i].x=answers[i].x
				wordText[i].y = answers[i].y+answers[i].height/3-MyData.height*0.005

				answerText[i].y=answers[i].y+answers[i].height/2
			else 
				answers[i].y=answers[i-1].y+answers[i-1].height
				answerText[i].x=answers[i].x
				wordText[i].y = answers[i].y+answers[i].height/3-MyData.height*0.005

				answerText[i].y=answers[i].y+answers[i].height/2
			end
		end

		answers[i].text=answerText[i]
		answers[i].correctWord=wordDef[i].word
	end 

end








local function buttonTouch( event )
    if event.phase=="ended" then 
        if event.target.name=="back" then 
            -- composer.gotoScene( "Home_V1","iosSlideRight",350 )
            composer.gotoScene( "Home","fade",350 )
        elseif event.target.name=="next" then 
        	newWord()
        end 
    end
end

local function createTopNavBar( ... )
	statusBar=display.newRect(0,0,MyData.width,MyData.StatusBarHeight)
    statusBar.anchorY=0
    statusBar.y=0
    statusBar.x=MyData.width*0.5
    statusBar:setFillColor(255/255,255/255,255/255)
    sceneGroup:insert(statusBar)

    topBanner=display.newRect(0,0,MyData.width,MyData.TopBannerHeight)
    topBanner.anchorY=0
    topBanner.y=MyData.StatusBarHeight
    topBanner.x=MyData.width*0.5
    topBanner:setFillColor(82/255,192/255,169/255)
    sceneGroup:insert(topBanner)

    local textOp={
            text="Learn",
            x=0,
            width=MyData.width*0.6,
            -- height=row.height*0.5,
            font=MyData.textFont,
            align="center",
            fontSize=MyData.bigfont,
        }


    BannerNewsName=display.newText(textOp)
    BannerNewsName:setFillColor(1,1,1)
    BannerNewsName.anchorX=0.5
    BannerNewsName.x=MyData.width*0.5
    BannerNewsName.anchorY=0.5
    BannerNewsName.y=topBanner.y+topBanner.height*0.5
    sceneGroup:insert(BannerNewsName)

    backButton=widget.newButton( 
        {
            label="Back",
            fontSize=MyData.midfont,
            font=MyData.textFont,
            width=MyData.TopBannerHeight,
            height=MyData.TopBannerHeight,
            fillColor={default={1,1,1},over={0,0,1}},
            labelColor={default={1,1,1},over={0.2,0.2,0.2}},
            onEvent=buttonTouch
        }
     )  
    backButton.x=MyData.TopBannerHeight*0.5 
    backButton.y=MyData.TopBannerHeight/2+MyData.StatusBarHeight 
    backButton.name="back"
    sceneGroup:insert(backButton)
    
    refreshButton=widget.newButton( 
        {
            label="10 more",
            fontSize=MyData.midfont,
            font=MyData.textFont,
            width=MyData.TopBannerHeight,
            height=MyData.TopBannerHeight,
            fillColor={default={1,1,1},over={0,0,1}},
            labelColor={default={1,1,1},over={0.2,0.2,0.2}},
            onEvent=buttonTouch
        }
     )  
    refreshButton.x=MyData.width-MyData.TopBannerHeight*0.5
    refreshButton.y=MyData.TopBannerHeight/2+MyData.StatusBarHeight 
    refreshButton.name="next"
    sceneGroup:insert(refreshButton)

    createWords()

end

function scene:create( event )
	sceneGroup = self.view

    background=display.newRect(0,0,MyData.width,MyData.height)
    background.anchorY=0
    background.y=0
    background.x=MyData.width*0.5
    background:setFillColor(10/255,10/255,10/255)
    sceneGroup:insert(background)


    createTopNavBar() 
end



function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then

		-- LevelTracker = loadsave.loadTable("LevelTracker.json", system.DocumentsDirectory)
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
		-- sceneGroup:addEventListener("touch",changeGravity)

	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen

		composer.removeScene("Quiz")
	end	
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.

end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
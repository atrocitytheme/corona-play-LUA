local sqlite3 = require("sqlite3")
local json = require("json")

local M = {}
	
	M.randomWord = function(...)
		local path = system.pathForFile("entries.db", system.DocumentsDirectory)
		db = sqlite3.open(path)
		print(path)

		local sqlRows = "SELECT * FROM entries ORDER BY RANDOM() LIMIT 4;"
		local allWords = {}
		for a in db:nrows(sqlRows) do 
			print(json.encode(a))
			allWords[#allWords+1] = a
		end
		return allWords
	end

	M.randomTenWord = function(...)
		local path = system.pathForFile("entries.db", system.DocumentsDirectory)
		db = sqlite3.open(path)
		print(path)

		local sqlRows = "SELECT * FROM entries ORDER BY RANDOM() LIMIT 10;"
		local allWords = {}
		for a in db:nrows(sqlRows) do 
			print(json.encode(a))
			allWords[#allWords+1] = a
		end
		return allWords
	end

	M.randomOneWord = function(...)
		local path = system.pathForFile("entries.db", system.DocumentsDirectory)
		db = sqlite3.open(path)
		print(path)

		local sqlRows = "SELECT * FROM entries ORDER BY RANDOM() LIMIT 1;"
		local allWords = {}
		for a in db:nrows(sqlRows) do 
			print(json.encode(a))
			allWords[#allWords+1] = a
		end
		return allWords
	end

return M
local M = {}
local myData = require("MyData")
local widget = require("widget")
local animationBar = {}
M.menuShown = false

function M.triangle()
	transition.to(animationBar[1], {rotation=-45, time = 300})
	transition.to(animationBar[3], {rotation=45, time = 300})
	transition.to(animationBar[2], {alpha = 0, time = 300})
end



function M.ThreeLine( ... )
	transition.to(animationBar[1], {rotation=0, time = 500})
	transition.to(animationBar[3], {rotation=0, time = 500})
	transition.to(animationBar[2], {alpha = 1, time = 500})
end




local function buttonTouch(event)
	if(event.phase =="ended") then
		if M.menuShown == false then
			M.menuShown = true
			M.triangle()
			M.callback(true)
		elseif M.menuShown == true then
			M.menuShown = false
			M.ThreeLine()
			M.callback(false)
		end
	end
end

function M.init(sceneGroup, x, y, listener)
	if(listener and type(listener) =="function") then
		M.callback = listener
	else
		error("no callback function listerd")
	end

	for i=1, 3 do
		animationBar[i]=display.newRect(sceneGroup, x, y+(i-2)*myData.height*0.01, myData.width*0.05, myData.height*0.005)
	end

	local button = widget.newButton({
		shape = "roundRect",
		width = myData.TopBannerHeight,
		height = myData.TopBannerHeight,
		fillColor = {default = {1,1,1}, over={0,0,1}},
		onEvent = buttonTouch
		})
	button.alpha = 0
	button.isHitTestable = true
	button.anchorX = 0
	button.x = 0
	button.y = y
	sceneGroup:insert(button)
end



return M